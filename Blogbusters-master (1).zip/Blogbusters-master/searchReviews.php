<style>
.one-third {
	float:left;
	width:33.3%;
}
</style>
<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display header 
echo makeHeader("Blogbusters | Reviews");
echo startMain("Reviews Page");

//Output variable 
$output = '';

//Create search variables
if(isset($_POST['search'])){
	$searchq = $_POST['search'];
	$searchq = preg_replace("#[^0-9a-z]#i","",$searchq);
	
	//Get connection 
	$db = getConnection();
	
	//Create search query 
	$query = $db->query("SELECT * FROM reviews WHERE reviewName LIKE '%$searchq%' OR description LIKE '%$searchq%' OR imageURL LIKE '%$searchq%' OR author LIKE '%$searchq%' OR reviewID LIKE '%$searchq%'") or die("could not search!");
	$count = $db->query("SELECT count(*) FROM reviews WHERE reviewName LIKE '%$searchq%' OR description LIKE '%$searchq%' OR imageURL LIKE '%$searchq%' OR author LIKE '%$searchq%' OR reviewID LIKE '%$searchq%'")->fetchColumn();
	
	//If the search result equal 0 then nothing was found else display the form with results 
	if ($count == 0){
			$output = 'There was no search results!<br />';
	}
		else {
			while($searchr = $query->fetchObject()){
				$reviewName = $searchr->reviewName;
				$description = $searchr->description;
				$imageURL= $searchr->imageURL;
				$author = $searchr->author;
				$reviewID = $searchr->reviewID;
				
				$output .= 
					"<div class='one-third'>
					<img src='$imageURL' style='width:300px;height:300px;'>
					<p>Review name: $reviewName</p>
					<p>Author: $author</p>
					<p>$description</p></div></br>";
			}
		}
}						
?>

<?php
	
	//print the output variable 
	print("$output"); 	
	
	//if the user is logged in, display a read more button else display a sign up link 
	if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']) {
		if ($count > 0) {
			echo "<form method='post' action='displayReview.php'>";
				echo "<input type='text' name='reviewID' style='display:none' value=$reviewID readonly />";
				echo "<input type='submit' name='submit' value='Read more' />";
			echo "</form>";
		}
	}
		else {
	
			echo "Not a member? <a href='register.php'>sign up to read review</a>";
		}
?>

<?php
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>

