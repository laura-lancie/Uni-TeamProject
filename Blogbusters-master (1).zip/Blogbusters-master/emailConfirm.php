<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Email Confirmation");

// Start main page body
echo startSmallMain();
	echo "<h1>Email Confirmation</h1>";

	// Redirect users if no email address found
	if ((!isset($_GET['email'])) && (!isset($_GET['username']))) {
		echo "<p>No email provided. Please check your email inbox or return to <a href='register.php'>registration</a></p>";
	}
	
	// If email is in URL
	else {
		$email = $_GET['email'];
		$username = $_GET['username'];
		
		// Request details from database
		$stmt = $db->query( "SELECT `username` FROM `users` WHERE `email` = '$email'");
		$obj = $stmt->fetchObject();
		
		// If a result is found, process the below
		if($obj != null) {
		
			// If the username matches the database table
			if (password_verify($obj->username,$username)) {
			
				$confirm = 1;
				
				// Prepare SQL statement
				$sql = ("UPDATE `users` SET `emailConfirm` = :confirm WHERE `email` = :email");
				
				// Prepare values
				$stmt = $db->prepare($sql);
				$stmt->bindParam(':confirm', $confirm, PDO::PARAM_INT);
				$stmt->bindParam(':email', $email, PDO::PARAM_STR);
				
				// Execute statement
				$stmt->execute();
				
				echo "<p>Thank you for confirming your email!</p>";
				echo "<p>You can now <a href='login.php'>log in</a> to your profile</p>";
			}
			
			// If the given email does not match the username from the database
			else {
				echo "<p>Incorrect details provided. Please try the email verificaion link again or return to <a href='register.php'>registration</a></p>";
			}
		}
		
		// If email is not found in the database table
		else {
			echo "<p>The email provided does not match our records. Please try the link provided again or return to <a href='register.php'>registration</a></p>";
		}
		
	}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>