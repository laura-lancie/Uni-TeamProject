<?php
/******************************************************
------------------Required Configuration---------------
Please edit the following variables so the forum can
work correctly.
******************************************************/

// Include header, menu and other functions, plus config
require_once( "functions.php" );

//We log to the DataBase
$studentID = getStudentID();
$studentPass = getStudentPass();
mysql_connect('localhost', $studentID, $studentPass);
mysql_select_db($studentID);

/******************************************************
----------------------Initialization-------------------
******************************************************/
include('init.php');
?>