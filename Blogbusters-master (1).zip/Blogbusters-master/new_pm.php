<?php
// Include header, menu and other functions, plus config
require_once( "functions.php" );
require_once( "config.php" );

// Set session path
$studentID = getStudentID();
ini_set( "session.save_path", "/home/" . $studentID . "/sessionData" );

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader( "Blogbusters | New Personal Message" );
?>

	<?php
	//Checks user login, if login is correct it will then allow the user to create a new personal message 
	if ( isset( $_SESSION[ 'username' ] ) ) {
		$form = true;
		$otitle = '';
		$orecip = '';
		$omessage = '';
		if ( isset( $_POST[ 'title' ], $_POST[ 'recip' ], $_POST[ 'message' ] ) ) {
			$otitle = $_POST[ 'title' ];
			$orecip = $_POST[ 'recip' ];
			$omessage = $_POST[ 'message' ];
			if ( get_magic_quotes_gpc() ) {
				$otitle = stripslashes( $otitle );
				$orecip = stripslashes( $orecip );
				$omessage = stripslashes( $omessage );
			}
			if ( $_POST[ 'title' ] != ''
				and $_POST[ 'recip' ] != ''
				and $_POST[ 'message' ] != '' ) {
				$title = mysql_real_escape_string( $otitle );
				$recip = mysql_real_escape_string( $orecip );
				$message = mysql_real_escape_string( nl2br( htmlentities( $omessage, ENT_QUOTES, 'UTF-8' ) ) );
				$dn1 = mysql_fetch_array( mysql_query( 'select count(id) as recip, id as recipid, (select count(*) from pm) as npm from discussUsers where username="' . $recip . '"' ) );
				if ( $dn1[ 'recip' ] == 1 ) {
					if ( $dn1[ 'recipid' ] != $_SESSION[ 'userID' ] ) {
						$id = $dn1[ 'npm' ] + 1;
						if ( mysql_query( 'insert into pm (id, id2, title, user1, user2, message, timestamp, user1read, user2read)values("' . $id . '", "1", "' . $title . '", "' . $_SESSION[ 'userID' ] . '", "' . $dn1[ 'recipid' ] . '", "' . $message . '", "' . time() . '", "yes", "no")' ) ) {
							?>
	<div class="message">The PM have successfully been sent.<br/>
		<a href="list_pm.php">List of your Personal Messages</a>
	</div>
	<?php
							//Error messages if personal message was unable to send 
	$form = false;
	}
	else {
		$error = 'An error occurred while sending the PM.';
	}
	} else {
		$error = 'You cannot send a PM to yourself.';
	}
	} else {
		$error = 'The recipient of your PM doesn\'t exist.';
	}
	} else {
		$error = 'A field is not filled.';
	}
	} elseif ( isset( $_GET[ 'recip' ] ) ) {
		$orecip = $_GET[ 'recip' ];
	}
	if ( $form ) {
		if ( isset( $error ) ) {
			echo '<div class="message">' . $error . '</div>';
		}
		?>
	<div class="content">
		<?php
		//This shows the form for users to send a new personal message along with links to direct user to the Forum Home, Their personal Personal Messages.
		$nb_new_pm = mysql_fetch_array( mysql_query( 'select count(*) as nb_new_pm from pm where ((user1="' . $_SESSION[ 'userID' ] . '" and user1read="no") or (user2="' . $_SESSION[ 'userID' ] . '" and user2read="no")) and id2="1"' ) );
		$nb_new_pm = $nb_new_pm[ 'nb_new_pm' ];
		?>
		<div class="box">
			<div class="box_left">
				<a href="discussIndex.php">Forum Home</a> &gt; <a href="list_pm.php">List of your PMs</a> &gt; New PM
			</div>
			<div class="box_right">
				<a href="list_pm.php">Your messages(<?php echo $nb_new_pm; ?>)</a> -
				<a href="profile.php">
					<?php echo htmlentities($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>
				</a>
			</div>
			<div class="clean"></div>
		</div>
		<h1>New Personal Message</h1>
		<form action="new_pm.php" method="post">
			Please fill this form to send a PM:<br/>
			<label for="title">Title</label><br/><input type="text" value="<?php echo htmlentities($otitle, ENT_QUOTES, 'UTF-8'); ?>" id="title" name="title"/><br/>
			<label for="recip">Recipient <span class="small">(Username)</span></label><br/><input type="text" value="<?php echo htmlentities($orecip, ENT_QUOTES, 'UTF-8'); ?>" id="recip" name="recip"/><br/>
			<label for="message">Message</label><br/><textarea cols="40" rows="5" id="message" name="message"><?php echo htmlentities($omessage, ENT_QUOTES, 'UTF-8'); ?></textarea><br/>
			<input type="submit" value="Send"/>
		</form>
	</div>
	<?php
	} //Error message informing user that they must be logged in to send personal messages 
	} else {
		?>
	<div class="message">You must be logged to access this page.</div>
	<div class="box_login">
		<form action="login.php" method="post">
			<label for="username">Username</label><input type="text" name="username" id="username"/><br/>
			<label for="password">Password</label><input type="password" name="password" id="password"/><br/>
			<label for="memorize">Remember</label><input type="checkbox" name="memorize" id="memorize" value="yes"/>
			<div class="center">
				<input type="submit" value="Login"/> <input type="button" onclick="javascript:document.location='signup.php';" value="Sign Up"/>
			</div>
		</form>
	</div>
	<?php
	}
	?>

	<?php
	// Display footer
	echo makeFooter();
	?>


</body>
</html>