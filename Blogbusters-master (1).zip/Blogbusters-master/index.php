<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Home");

// Start main page body
echo startMain();

// Call search bar
echo searchBar();
?>
	<!-- Main banner !-->
	<section class="slider">
		<div class="slider-container">
			<img src="images/slider1.png" />
			<img src="images/slider2.png" />
			<img src="images/slider3.png" />
		</div>
	</section>

	<!-- Welcome message !-->
	<?php
	if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']) {
		echo "<h1>Welcome ".$_SESSION['username'].", check out some of our reviews!</h1>";
	}
	else {
		echo "<h1>Check out some of our available reviews!</h1>";
	}

	// Display selected reviews
	$count = $db->query("SELECT count(*) FROM `reviews`")->fetchColumn();
	if ($count > 4) {
		$count = 4;
	}
	
	echo "<div class='wrapper'>";
		if ($count > 0) {
			$stmt = $db->query( "SELECT `reviewID`, `reviewName`, `imageURL` FROM `reviews` ORDER BY RAND() LIMIT $count");
			while ( $obj = $stmt->fetchObject()) {
				echo "<div class='indexContainer' style='width:".(100/$count)."%;'>";
					echo "<form name='review' method='post' action='displayReview.php'>";
						echo "<input type='text' name='reviewID' style='display:none' value=".$obj->reviewID." readonly />";
						echo "<input type='image' src=".$obj->imageURL." alt=".$obj->reviewName." /><br />";
						echo "<input type='submit' class='reviewLink' value='".$obj->reviewName."' />";
					echo "</form>";
				echo "</div>";
			}
		}
	echo "</div>";
	
	if (!isset($_SESSION['logged-in'])) {
		echo "<h3><a href='login.php'>Log in</a> or <a href='register.php'>sign up</a> to access these reviews and much more!</h3>";
	}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>