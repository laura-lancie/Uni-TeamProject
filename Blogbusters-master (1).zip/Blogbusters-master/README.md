# Blogbusters - Movie Review Web Application

This is a web application created using PHP, MySQL, PDO,  Xml, HTML, CSS and JavaScript. 
This application  is a movie review website with the following features:
- Users of different admin levels can create accounts 
  (admins can edit, suspend and delete accounts, Guests without accounts can only view content)
- Post, edit, delete and comment on review content, depending on account level.
- See, edit, delete and join/sign up to events (Calendared), depending on account level.
- Join the community discussion board, post comments and send personal messages, depending on account level.
- Search Reviews to find content.

## Getting Started
These instructions will get you a copy of the project up and running on your local machine for development, testing and deployment purposes.

### Prerequisites
To install the software a hosting network will be needed, the recommended is GoDaddy Uk as it has the required database features needed
to hold data for this application.


### Installing (Informaiton for accessing the websites login access levels)

System Details: 

Hosted on NewNuMySpace (URL: http://unn-w18029630.newnumyspace.co.uk/KV6002/index.php)

There are currently six users registered with the website:

#### Administrator access level:
  
  username: Administrator<br />
  password: admin
  <br /><br />
  username: JennieSmithson<br />
  password: password
  
#### Moderator access level:
  
  username: Macky_5150<br />
  password: Pass123

#### Reviewer access level:
  
  username: Laura_A<br />
  password: Lauraatkin
  <br /><br />
  username: cirving<br />
  password: cirving

#### User access level:
  
  username: Gardner_Reviews<br />
  password: pass123

Guests can view webiste by using URL but not use features available to the other accounts.

## Built With
PHP, MySQL, PDO,  Xml, HTML, CSS and JavaScript

## Versioning
We use Github for versioning. All files for this project are submitted on github.

## Authors
- David McDowell - Administration system, pages and functions, including log in, registration, user profiles and profile edit. General website functionality, navigation / footer sections, mobile formatting, Home and About Us pages and website integration
- Laura Atkin - Events page/functions and calendar functions, including Home page features
- Jennie Smithson - Community Discussion Board
- Chris Irving - Reviews page and review functions
- Chad Gardner - Search bar and search features

## License
Copyright - David McDowell, Laura Atkin, Jennie Smithson, Chris Irving and Chad Gardner / 2019
(For use of this project, explicit permission is needed from all authors involved). 

