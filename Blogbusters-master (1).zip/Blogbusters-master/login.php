<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Log In");

// Start main page body
echo startSmallMain();
?>
		<!-- Display log in form !-->
		<h1 style="text-align: center;">Log In</h1>
		<p>Not a member? <a href = "register.php">Sign up</a> to be part of our community!</p>
		<form name="login" method="post" action="loginProcess.php">
			<fieldset>
				<br />
				<label for="user">Username or Email:</label><br />
				<input type="text" name="user" required><br /><br />
				<label for="password">Password:</label><br />
				<input type="password" name="password" required><br /><br />
				<div style="width: 90%;">
					<input type="submit" name="submit" value="Log In" style="float: right;">
				</div>
				<br /><br />
			</fieldset>
			<p style="text-align:center;">Forgotten your password? <a href="forgotPassword.php">Click here</a></p>
		</form>
<?php
// End main body
echo endMain();

// Display footer
echo makeFooter();
?>