<style>
.one-half {
	float:left;
	width:50%;
}
@media screen and (max-width: 1080px) {
	.one-half {
	float:left;
	width: 100%;
	text-align:center;
}
}
</style>
<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display Header 
echo makeHeader("Blogbusters | Reviews");
echo startMain("Reviews Page");

if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
		//If the access level is equal to 'Reviewer' then the 'Add Review' link will appear
		if (getAccessLevel($_SESSION['username'])=="Reviewer" OR "Administrator" OR "Moderator") {
			echo "<p> <a href='addReview.php'>Add a Review </a></p>";
				}
}
		// Call search bar
		echo searchBar();
		
		//Selecting data from the 'reviews' table 
		$sql = "SELECT reviewID,reviewName,author, description, imageURL FROM reviews";

			//Start posting query 
			$displayReviews = $db->query($sql);		
			
				//Fetch data when the results match the variables 
				while	($reviewPost = $displayReviews->fetchObject() ) {
					$reviewID = $reviewPost->reviewID;
					$reviewName = $reviewPost->reviewName;
					$author = $reviewPost->author;
					$description = $reviewPost->description; 
					$imageURL = $reviewPost->imageURL;
					
						//Creating third class to display the forms into three sections on the page
						echo "<div class='one-half'>";
						echo "<img src='$imageURL' style='width:300px;height:300px;'>";
						echo "<p>Review name: $reviewName</p>";
						echo "<p>Author: $author</p>";
						echo "$description</p>";
					
						//Creating a form to display the 'Read more' button 
						if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
							echo "<form method='post' action='displayReview.php'>";
							echo "<input type='text' name='reviewID' style='display:none' value=$reviewID readonly/>";
							echo "<input type='submit' name='submit' value='Read more'/>";
							echo "</form>"; 
						}
						else {
							echo "Not a member? <a href='register.php'>sign up to read review</a></br></br>";
						}
					
				//If the username is equal to the author display both 'Edit Review' and 'Delete Review' buttons
				if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
				if ($_SESSION['username']=="$author") {
					
					echo "<form method='post' action='editReview.php'>";
					echo "<input type='text' name='reviewID' style='display:none' value=$reviewID readonly/>";
					echo "<input type='submit' name='submit' value='Edit Review'/>";
					echo "</form>";
					
					echo "<form method='post' action='deleteReview.php'>";
					echo "<input type='text' name='reviewID' style='display:none' value=$reviewID readonly/>";
					echo "<input type='submit' name='submit' value='Delete Review'/>";
					echo "</form>";
				}
				}
					echo "</div>";
				}
				


//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>