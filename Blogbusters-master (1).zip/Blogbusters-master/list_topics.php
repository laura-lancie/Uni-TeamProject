<?php
// Include header, menu and other functions, plus config
require_once( "functions.php" );
require_once( "config.php" );

// Set session path
$studentID = getStudentID();
ini_set( "session.save_path", "/home/" . $studentID . "/sessionData" );

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader( "Blogbusters | List Topics" );

//This will pull from database the topics listed under indivial categories, if no topics are entered it will show a message to the user stating this
if ( isset( $_GET[ 'parent' ] ) ) {
	$id = intval( $_GET[ 'parent' ] );
	$dn1 = mysql_fetch_array( mysql_query( 'select count(c.id) as nb1, c.name,count(t.id) as topics from categories as c left join topics as t on t.parent="' . $id . '" where c.id="' . $id . '" group by c.id' ) );
	if ( $dn1[ 'nb1' ] > 0 ) {
		?>
			<div class="content">
				<?php
				if ( isset( $_SESSION[ 'username' ] ) ) {
					$nb_new_pm = mysql_fetch_array( mysql_query( 'select count(*) as nb_new_pm from pm where ((user1="' . $_SESSION[ 'userID' ] . '" and user1read="no") or (user2="' . $_SESSION[ 'userID' ] . '" and user2read="no")) and id2="1"' ) );
					$nb_new_pm = $nb_new_pm[ 'nb_new_pm' ];
					?>
				<div class="box">
					<div class="box_left">
						<a href="discussIndex.php">Forum Home</a> &gt;
						<a href="list_topics.php?parent=<?php echo $id; ?>">
							<?php echo htmlentities($dn1['name'], ENT_QUOTES, 'UTF-8'); ?>
						</a>
					</div>
					<div class="box_right">
						<a href="list_pm.php">Your messages(<?php echo $nb_new_pm; ?>)</a> -
						<a href="profile.php">
							<?php echo htmlentities($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>
						</a>
					</div>
					<div class="clean"></div>
				</div>
				<?php
				} else {
					?>
				<div class="box">
					<div class="box_left">
						<a href="discussIndex.php">Forum Home</a> &gt;
						<a href="list_topics.php?parent=<?php echo $id; ?>">
							<?php echo htmlentities($dn1['name'], ENT_QUOTES, 'UTF-8'); ?>
						</a>
					</div>
					<div class="box_right">
						<a href="register.php">Sign Up</a> - <a href="login.php">Login</a>
					</div>
					<div class="clean"></div>
				</div>
				<?php
				}
				if ( isset( $_SESSION[ 'username' ] ) ) {
					?>
				<a href="new_topic.php?parent=<?php echo $id; ?>" class="button">New Topic</a>
				<?php
				}
				$dn2 = mysql_query( 'select t.id, t.title, t.authorid, u.username as author, count(r.id) as replies from topics as t left join topics as r on r.parent="' . $id . '" and r.id=t.id and r.id2!=1  left join discussUsers as u on u.id=t.authorid where t.parent="' . $id . '" and t.id2=1 group by t.id order by t.timestamp2 desc' );
				if ( mysql_num_rows( $dn2 ) > 0 ) {
					?>
				<table class="topics_table">
					<tr>
						<th class="forum_tops">Topic</th>
						<th class="forum_auth">Author</th>
						<th class="forum_nrep">Replies</th>
						<?php
						if ( isset( $_SESSION[ 'username' ] )and getAccessLevel( $_SESSION[ 'username' ] ) == "Administrator" ) {
							?>
						<th class="forum_act">Action</th>
						<?php
						}
						?>
					</tr>
					<?php
					while ( $dnn2 = mysql_fetch_array( $dn2 ) ) {
						?>
					<tr>
						<td class="forum_tops">
							<a href="read_topic.php?id=<?php echo $dnn2['id']; ?>">
								<?php echo htmlentities($dnn2['title'], ENT_QUOTES, 'UTF-8'); ?>
							</a>
						</td>
						<td>
							<form method='post' action='profile.php'>
								<input type='submit' name='username' class='profileLink' style='font-weight:normal;' value='<?php echo $dnn2['author'];?>' />
							</form>
						</td>
						<td>
							<?php echo $dnn2['replies']; ?>
						</td>
						<?php
						if ( isset( $_SESSION[ 'username' ] )and getAccessLevel( $_SESSION[ 'username' ] ) == "Administrator" ) {
							?>
						<td><a href="delete_topic.php?id=<?php echo $dnn2['id']; ?>"><img src="images/delete.png" alt="Delete" /></a>
						</td>
						<?php
						}
						?>
					</tr>
					<?php
					}
					?>
				</table>
				<?php
				} else {
					?>
				<div class="message">This category has no topic.</div>
				<?php
				}
				if ( isset( $_SESSION[ 'username' ] ) ) {
					?>
				<a href="new_topic.php?parent=<?php echo $id; ?>" class="button">New Topic</a>
				<?php
				} else {
					?>
				<div class="box_login">
					<form action="login.php" method="post">
						<label for="username">Username</label><input type="text" name="username" id="username"/><br/>
						<label for="password">Password</label><input type="password" name="password" id="password"/><br/>
						<label for="memorize">Remember</label><input type="checkbox" name="memorize" id="memorize" value="yes"/>
						<div class="center">
							<input type="submit" value="Login"/> <input type="button" onclick="javascript:document.location='signup.php';" value="Sign Up"/>
						</div>
					</form>
				</div>
				<?php
				}
				?>
			</div>
			<?php
			// Display footer
			echo makeFooter();
			?>
		</body>
		</html>
		<?php
	} else {
		echo '<h2>This category doesn\'t exist.</h2>';
	}
} else {
	echo '<h2>The ID of the category you want to visit is not defined.</h2>';
}
?>