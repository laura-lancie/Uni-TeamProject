<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Profile");

// If logged in, display content
if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
	
	// If logged in, ascertain which profile has been clicked
	if (isset($_REQUEST['username'])) {
		$username = $_REQUEST['username'];
	}
	
	// If no profile has been clicked, display user's own profile
	else {
		$username = $_SESSION['username'];
	}
	
	// Retrieve data from database and process
	$stmt = $db->query( "SELECT * FROM `users` WHERE `username` = '$username'");
	$obj = $stmt->fetchObject();
	
	echo startMain();
	?>
				<div class="wrapper">
					<div class="profileHeader">
						<?php
						// Display user image, if available, regardless of which logged user accesses the page
						if ($obj->imageURL!=null){
							echo "<img class='profileImage' src=".$obj->imageURL." alt=".$obj->username."/>";
						}
						?>
					</div>
					
					<div class="profileHeader">
						<!-- Display user name !-->
						<h1><?php echo $username ?></h1>
						
						<?php
						// Only display first name and surname details to profile owner
						if ($_SESSION['username'] == $username) {
							echo "<p>".$obj->firstName." ".$obj->surname."</p>";
						}
						?>
						
						<!-- Display join date !-->
						<p style="font-size:90%;margin-top:-15px;">Joined on <?php echo date("jS F Y",strtotime($obj->joinDate))?></p>
					</div>
				</div>
				<br /><br />
				<div class="wrapper">
					<div style="width: 100%; clear: both; text-align: left;">
						<?php
						// If user bio is available, follow one of two actions
						if ($obj->bio != null) {
							
							// If user bio is public, display to all
							if ($obj->display==1) {
								echo "<p><strong>Bio:</strong></p>";
								echo "<p><pre>".$obj->bio."</pre></p>";
							}
							
							// If user bio is not public, display only to profile owner
							else if ($_SESSION['username'] == $username) {
								echo "<p><strong>Bio:</strong>";
								echo "<em> *not currently displayed to other users</em>";
								echo "</p>";
								echo "<p><pre>".$obj->bio."</pre></p>";
							}
						}
						?>
					</div>
				</div>
				
				<?php
				// If user social media is available, follow one of two actions
				if ($obj->facebook!=null || $obj->twitter!=null || $obj->instagram!=null) {
					$count = 1;
					if ($obj->facebook!=null && $obj->twitter!=null || $obj->facebook!=null && $obj->instagram!=null || $obj->twitter!=null && $obj->instagram!=null) {
						$count = 2;
					}
					if ($obj->facebook!=null && $obj->twitter!=null && $obj->instagram!=null) {
						$count = 3;
					}
					echo "<div class='wrapper'>";
					
						// If user social media is public, display to all
						if ($obj->display==1){
							echo "<p><strong>Social Media:</strong></p>";
							if ($obj->facebook!=null){
								echo "<div class='socialContainer' style='width:".(100/$count)."%;'>";
									echo "<a href='https://www.facebook.com/".$obj->facebook."'><img class='profileSocial' src='images/fb-logo.png' alt='facebook' /></a>";
									echo "</p><a href='https://www.facebook.com/".$obj->facebook."'>".$obj->facebook."</a></p>";
								echo "</div>";
							}
							if ($obj->twitter!=null){
								echo "<div class='socialContainer' style='width:".(100/$count)."%;'>";
									echo "<a href='https://www.twitter.com/".$obj->twitter."'><img class='profileSocial' src='images/twitter-logo.png' alt='twitter' /></a>";
									echo "</p><a href='https://www.twitter.com/".$obj->twitter."'>".$obj->twitter."</a></p>";
								echo "</div>";
							}
							if ($obj->instagram!=null){
								echo "<div class='socialContainer' style='width:".(100/$count)."%;'>";
									echo "<a href='https://www.instagram.com/".$obj->instagram."'><img class='profileSocial' src='images/instagram-logo.png' alt='instagram' /></a>";
									echo "</p><a href='https://www.instagram.com/".$obj->instagram."'>".$obj->instagram."</a></p>";
								echo "</div>";
							}
						}
					
						// If user social media is not public, display only to profile owner
						else if ($_SESSION['username'] == $username) {
							echo "<p><strong>Social Media:</strong>";
							echo "<em> *not currently displayed to other users</em></p>";
							if ($obj->facebook!=null){
								echo "<div class='socialContainer' style='width:".(100/$count)."%;'>";
									echo "<a href='https://www.facebook.com/".$obj->facebook."'><img class='profileSocial' src='images/fb-logo.png' alt='facebook' /></a>";
									echo "</p><a href='https://www.facebook.com/".$obj->facebook."'>".$obj->facebook."</a></p>";
								echo "</div>";
							}
							if ($obj->twitter!=null){
								echo "<div class='socialContainer' style='width:".(100/$count)."%;'>";
									echo "<a href='https://www.twitter.com/".$obj->twitter."'><img class='profileSocial' src='images/twitter-logo.png' alt='twitter' /></a>";
									echo "</p><a href='https://www.twitter.com/".$obj->twitter."'>".$obj->twitter."</a></p>";
								echo "</div>";
							}
							if ($obj->instagram!=null){
								echo "<div class='socialContainer' style='width:".(100/$count)."%;'>";
									echo "<a href='https://www.instagram.com/".$obj->instagram."'><img class='profileSocial' src='images/instagram-logo.png' alt='instagram' /></a>";
									echo "</p><a href='https://www.instagram.com/".$obj->instagram."'>".$obj->instagram."</a></p>";
								echo "</div>";
							}
						}
					echo "</div>";
				}
					
					// Display edit profile button if user is viewing their own profile
					if ($_SESSION['username'] == $username) {
						echo "<hr />";
						echo "<div class='wrapper'>";
							echo "<form name='user' method='post' action='profileEdit.php'>";
								echo "<input type='submit' name='submit' value='Edit Profile'>";
							echo "</form>";
						echo "</div>";
					}
}

	// If not logged in, display redirection message
	else {
		echo startSmallMain();
					echo "<h1>Page Not Accessible</h1>";
					echo "You do not have permission to access this page. Please <a href='login.php'>log in</a>, <a href='register.php'>sign up</a> or return to the <a href='index.php'>home page</a>.";
	}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>