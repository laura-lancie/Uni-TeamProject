-- phpMyAdmin SQL Dump
-- version 4.2.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 22, 2019 at 09:32 AM
-- Server version: 5.5.58-0+deb7u1-log
-- PHP Version: 5.6.31-1~dotdeb+7.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `unn_w18031977`
--

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE IF NOT EXISTS `reviews` (
`reviewID` int(11) NOT NULL,
  `reviewName` varchar(50) NOT NULL,
  `author` varchar(50) NOT NULL,
  `description` varchar(100) NOT NULL,
  `review` varchar(1000) NOT NULL,
  `imageURL` varchar(255) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=87 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`reviewID`, `reviewName`, `author`, `description`, `review`, `imageURL`) VALUES
(80, 'Guardians of the galaxy (2014)', 'cirving', 'Guardians of the Galaxy (Marvel movie)', 'Guardians of the Galaxy does the impossible. Through dazzle and dumb luck, it turns the clichÃ©s of comic-book films on their idiot heads and hits you like an exhilarating blast of fun-fun-fun. It''s insanely, shamelessly silly â€“ just one reason to love it. ', 'images/guardians.jpg'),
(85, 'An American werewolf in London ', 'cirving', 'Beware the moors!!', 'Zombies and vampires appear to rule the scary-movie world right now, so here''s a reminder of the time in the 1980s when werewolves had their Â­moment in the sun, or rather the moon. This is John Landis''s eccentric comedy-horror hybrid about a couple of American backpackers, Griffin Dunne and David Naughton, visiting traditional Olde England and getting bitten by more than just the travel bug. Scary-funny is an acquired taste. For me, it tends to be a recipe in which you can''t taste either of the constituent ingredients. The big man-to-wolf transformation scene is still a marvel.', 'images/image.jpg'),
(86, 'The wizard of Oz', 'ironman123', 'Best movie ever!', 'What exactly are we reviewing here? The film, which is such a timeless classic that most children know it by heart by the age of four? Or the 3D Imax retrofit, which has blown the picture up to gigantic size and imposed an entirely unnecessary stereoscopy upon images that never felt the least bit â€œflatâ€ in the first place? ', 'images/The-Wizard-Of-Oz-the-wizard-of-oz-28449628-1024-768.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
 ADD PRIMARY KEY (`reviewID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
MODIFY `reviewID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=87;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
