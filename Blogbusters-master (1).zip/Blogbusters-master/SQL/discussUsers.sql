-- phpMyAdmin SQL Dump
-- version 4.2.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 21, 2019 at 04:50 PM
-- Server version: 5.5.58-0+deb7u1-log
-- PHP Version: 5.6.31-1~dotdeb+7.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `unn_w18027865`
--

-- --------------------------------------------------------

--
-- Table structure for table `discussUsers`
--

CREATE TABLE IF NOT EXISTS `discussUsers` (
  `id` bigint(20) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `avatar` text NOT NULL,
  `signup_date` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `discussUsers`
--

INSERT INTO `discussUsers` (`id`, `username`, `password`, `email`, `avatar`, `signup_date`) VALUES
(0, 'admin', 'password', 'admin@password.co.uk', '', 0),
(2, 'Jennie', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'smithsonjennie@outlook.com', '', 1555746589),
(3, 'Laura', '7c4a8d09ca3762af61e59520943dc26494f8941b', 'Laura@outlook.com', '', 1555747452),
(4, 'Jen', '5baa61e4c9b93f3f0682250b6cf8331b7ee68fd8', 'jen@gmail.com', '', 1555764916);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
