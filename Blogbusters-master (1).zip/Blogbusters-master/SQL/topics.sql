-- phpMyAdmin SQL Dump
-- version 4.2.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 20, 2019 at 12:53 PM
-- Server version: 5.5.58-0+deb7u1-log
-- PHP Version: 5.6.31-1~dotdeb+7.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `unn_w18027865`
--

-- --------------------------------------------------------

--
-- Table structure for table `topics`
--

CREATE TABLE IF NOT EXISTS `topics` (
  `parent` smallint(6) NOT NULL,
  `id` int(11) NOT NULL,
  `id2` int(11) NOT NULL,
  `title` varchar(256) NOT NULL,
  `message` longtext NOT NULL,
  `authorid` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `timestamp2` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `topics`
--

INSERT INTO `topics` (`parent`, `id`, `id2`, `title`, `message`, `authorid`, `timestamp`, `timestamp2`) VALUES
(1, 1, 2, '', 'add comment', 2, 1555746846, 1555746846),
(1, 2, 1, 'Laura', 'sfnsg sgsgsgs sgsgsgsgswg', 3, 1555747489, 1555757308),
(1, 2, 2, '', 'titiktuikui', 2, 1555757308, 1555757308),
(1, 3, 1, 'Harry Potter', 'Harry Potter Fans', 2, 1555757358, 1555759906),
(1, 3, 2, '', 'fgdhdthtde', 2, 1555759906, 1555759906),
(2, 4, 1, 'Horror', 'Lorem ipsum dolor sit amet consectetur adipiscing elit sapien, suspendisse tortor ad tristique quam fames scelerisque, metus diam tempus varius lobortis et sagittis. Accumsan mi habitasse sapien cursus nulla quis at placerat dapibus, nisl nibh sagittis eu fusce ad nisi posuere per natoque, netus et ullamcorper velit fames suscipit tellus lectus. Himenaeos dui ad cubilia inceptos proin justo suscipit, integer mus sollicitudin eleifend sodales vulputate ridiculus, convallis facilisi netus sapien mattis vivamus.<br />\r\nPharetra aliquam vehicula mauris cum leo congue nascetur nec, mus nisi enim ullamcorper blandit tortor venenatis. Venenatis varius malesuada sociis integer arcu tellus praesent ligula at, porta maecenas sed faucibus pretium accumsan nascetur phasellus, enim tortor duis conubia sapien sollicitudin inceptos penatibus. Taciti per cursus semper commodo ut mollis tristique nam cubilia, odio primis neque in eu imperdiet varius turpis sociosqu eget, volutpat viverra congue quis malesuada lacinia orci platea.', 2, 1555760301, 1555760301);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `topics`
--
ALTER TABLE `topics`
 ADD PRIMARY KEY (`id`,`id2`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
