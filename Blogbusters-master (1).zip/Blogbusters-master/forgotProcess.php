<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Include PHPMailer functionality
use PHPMailer\PHPMailer\PHPMailer;

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Reset Password");

// If details have been passed from previous page, process the below
if (isset($_REQUEST['email'])) {

	// Request data from forgotten password form
	$email = $_REQUEST['email'];

	// Return user to forgotten password page if email not in the database
	$stmt = $db->query( "SELECT `username`, `email` FROM `users` WHERE `email` = '$email'");
	$obj = $stmt->fetchObject();
	if (!isset($obj->email)) {
		// Start main page body
		echo startSmallMain();
					echo "<h1>Email not found</h1>";
					echo "<p>The email you provided does not match our records. Please return to <a href='forgotPassword.php'>forgot password</a></p>";
	}
			
	// If email is found in the database, follow below processes
	else {
		// Save username from database
		$username = $obj->username;
		
		// Create and hash password token, inclduing salt
		$token = mt_rand(10000,mt_getrandmax());
		$options = ['cost'=>12,];
		$tokenHash = password_hash($token,PASSWORD_DEFAULT,$options);
			
		// Set reset email
		include_once ("PHPMailer/PHPMailer.php");
		$mail = new PHPMailer();
		$mail->setFrom($studentEmail);
		$mail->addAddress($email, $username);
		$mail->Subject = "Blogbusters Password Reset";
		$mail->isHTML(true);
		$mail->Body =	"<p>Hi, $username</p>
				 <p>Please click on the link below to reset your password:</p>
				 <p><a href='http://".$studentID.".newnumyspace.co.uk/".$directory."/passwordReset.php?email=$email&tempPassword=$tokenHash'>Click here</a></p>";
		$mail->send();
				
	// Return a message to the user that the profile has been created and log in is pending email confirmation
			
	// Start main page body
	echo startSmallMain();
				echo "<h1>Password Reset</h1>";
				echo "<p>A link to reset your password has been set to the following email address:</p>";
				echo "<p><strong>Email:</strong> $email</p>";
				echo "<p>Follow the link in the email to reset your password</p>";
				echo "<p>Please ensure to check your spam folder if the email is not in your inbox</p>";
				
	// Prepare SQL statement
	$sql = "UPDATE `users` SET `tempPassword`= :tempPassword WHERE `email` = '$email'";
				
	// Prepare values
	$stmt = $db->prepare($sql);
	$stmt->bindParam(':tempPassword', $tokenHash, PDO::PARAM_STR);

	// Execute statement
	$stmt->execute();
	}
}

// If no details have been passed, display redirection message
else {
	// Start main page body
	echo startSmallMain();
				echo "<h1>Page Not Accessible</h1>";
				echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>