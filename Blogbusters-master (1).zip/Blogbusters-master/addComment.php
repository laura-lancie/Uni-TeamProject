<style>
form {
	text-align:center;
}
</style>
<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();
	
//Display header
echo makeHeader("Blogbusters | Add Comment");
echo startMain("Add Comments Page");

	//Request data from 'comment' table 
	if(isset($_REQUEST['userComment'])){
		$userComment = $_REQUEST['userComment'];
		$rating = $_REQUEST['rating']; 

		$stmt = $db->query( "SELECT `userComment` FROM `comment`");
		$obj = $stmt->fetchObject();
	}

	//Insert Data into 'comment' table 
	$sql = "INSERT INTO comment (userComment, rating) VALUES (:userComment,:rating)";  

	$stmt = $db->prepare($sql); 
	$stmt->bindParam(':userComment', $userComment, PDO::PARAM_STR);
	$stmt->bindParam(':rating', $rating, PDO::PARAM_STR);
	$stmt->execute(); 
	
		//echo message and link that a comment has been added and check it out
		echo "<form>";
		echo "<p>You have added a comment!</p></br>";
		echo "<p>Check out <a href='displayComment.php'>User comments</p>";
		echo "</form>";
		
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>				