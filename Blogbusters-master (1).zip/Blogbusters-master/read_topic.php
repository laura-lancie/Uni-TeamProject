<?php
// Include header, menu and other functions, plus config
require_once( "functions.php" );
require_once( "config.php" );

// Set session path
$studentID = getStudentID();
ini_set( "session.save_path", "/home/" . $studentID . "/sessionData" );

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader( "Blogbusters | Read Topic" );
if ( isset( $_GET[ 'id' ] ) ) {
	$id = intval( $_GET[ 'id' ] );
	$dn1 = mysql_fetch_array( mysql_query( 'select count(t.id) as nb1, t.title, t.parent, count(t2.id) as nb2, c.name from topics as t, topics as t2, categories as c where t.id="' . $id . '" and t.id2=1 and t2.id="' . $id . '" and c.id=t.parent group by t.id' ) );
	if ( $dn1[ 'nb1' ] > 0 ) {
		?>
		<div class="content">
			<?php //Looks for logged in user  
if(isset($_SESSION['username']))
{
$nb_new_pm = mysql_fetch_array(mysql_query('select count(*) as nb_new_pm from pm where ((user1="'.$_SESSION['userID'].'" and user1read="no") or (user2="'.$_SESSION['userID'].'" and user2read="no")) and id2="1"'));
$nb_new_pm = $nb_new_pm['nb_new_pm'];
?>
			<div class="box">
				<div class="box_left">
					<a href="discussIndex.php">Forum Home</a> &gt;
					<a href="list_topics.php?parent=<?php echo $dn1['parent']; ?>">
						<?php echo htmlentities($dn1['name'], ENT_QUOTES, 'UTF-8'); ?>
					</a> &gt;
					<a href="read_topic.php?id=<?php echo $id; ?>">
						<?php echo htmlentities($dn1['title'], ENT_QUOTES, 'UTF-8'); ?>
					</a> &gt; Read the topic
				</div>
				<div class="box_right">
					<a href="list_pm.php">Your messages(<?php echo $nb_new_pm; ?>)</a> -
					<a href="profile.php">
						<?php echo htmlentities($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>
					</a>
				</div>
				<div class="clean"></div>
			</div>
			<?php // If user is not logged in or does not hold an account this will redirect the user back to the login page
			} else {
				?>
			<div class="box">
				<div class="box_left">
					<a href="discussIndex.php">Forum Home</a> &gt;
					<a href="list_topics.php?parent=<?php echo $dn1['parent']; ?>">
						<?php echo htmlentities($dn1['name'], ENT_QUOTES, 'UTF-8'); ?>
					</a> &gt;
					<a href="read_topic.php?id=<?php echo $id; ?>">
						<?php echo htmlentities($dn1['title'], ENT_QUOTES, 'UTF-8'); ?>
					</a> &gt; Read the topic
				</div>
				<div class="box_right">
					<a href="register.php">Sign Up</a> - <a href="login.php">Login</a>
				</div>
				<div class="clean"></div>
			</div>
			<?php //If user is logged in with a valid account it will then allow the user to read the topics and send a reply 
			}
			?>
			<h1>
				<?php echo $dn1['title']; ?> 
			</h1>
			<?php
			if ( isset( $_SESSION[ 'username' ] ) ) {
				?>
			<a href="new_reply.php?id=<?php echo $id; ?>" class="button">Reply</a>
			<?php
			}
			$dn2 = mysql_query( 'select t.id2, t.authorid, t.message, t.timestamp, u.username as author, u.avatar from topics as t, discussUsers as u where t.id="' . $id . '" and u.id=t.authorid order by t.timestamp asc' );
			?>
			<table class="messages_table">
				<tr>
					<th class="author">Author</th>
					<th>Message</th>
				</tr>
				<?php
				while ( $dnn2 = mysql_fetch_array( $dn2 ) ) {
					?>
				<tr>
					<td class="author center">
						<?php
						if ( $dnn2[ 'avatar' ] != '' ) {
							echo '<img src="' . htmlentities( $dnn2[ 'avatar' ] ) . '" alt="Image Perso" style="max-width:100px;max-height:100px;" />';
						}
						?><br/>
							<form method='post' action='profile.php'>
								<input type='submit' name='username' class='profileLink' style='font-weight:normal;' value='<?php echo $dnn2['author'];?>' />
							</form>
					</td>
					<td class="left">
						<?php if(isset($_SESSION['username']) and ($_SESSION['username']==$dnn2['author'] or getAccessLevel($_SESSION['username'])=="Administrator")){ ?>
						<div class="edit"><a href="edit_message.php?id=<?php echo $id; ?>&id2=<?php echo $dnn2['id2']; ?>"><img src="images/edit.png" alt="Edit" /></a>
						</div>
						<?php } ?>
						<div class="date">Date sent:
							<?php echo date('Y/m/d H:i:s' ,$dnn2['timestamp']); ?>
						</div>
						<div class="clean"></div>
						<?php echo $dnn2['message']; ?>
					</td>
				</tr>
				<?php
				}
				?>
			</table>
			<?php // Error message and/or User Restrictions
			if ( isset( $_SESSION[ 'username' ] ) ) {
				?>
			<a href="new_reply.php?id=<?php echo $id; ?>" class="button">Reply</a>
			<?php
			} else {
				?>
			<div class="box_login">
				<form action="login.php" method="post">
					<label for="username">Username</label><input type="text" name="username" id="username"/><br/>
					<label for="password">Password</label><input type="password" name="password" id="password"/><br/>
					<label for="memorize">Remember</label><input type="checkbox" name="memorize" id="memorize" value="yes"/>
					<div class="center">
						<input type="submit" value="Login"/> <input type="button" onclick="javascript:document.location='signup.php';" value="Sign Up"/>
					</div>
				</form>
			</div>
			<?php
			}
			?>
		</div>
		<?php
		// Display footer
		echo makeFooter();
		?>
		</body>
		</html>
		<?php
	} else {
		echo '<h2>This topic doesn\'t exist.</h2>';
	}
} else {
	echo '<h2>The ID of this topic is not defined.</h2>';
}
?>