<?php
// Include header, menu and other functions, plus config
require_once( "functions.php" );
require_once( "config.php" );

// Set session path
$studentID = getStudentID();
ini_set( "session.save_path", "/home/" . $studentID . "/sessionData" );

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader( "Blogbusters | Delete Category" );

//Checks user is logged in as admin to be able to delete categories
if ( isset( $_GET[ 'id' ] ) ) {
	$id = intval( $_GET[ 'id' ] );
	$dn1 = mysql_fetch_array( mysql_query( 'select count(id) as nb1, name, position from categories where id="' . $id . '" group by id' ) );
	if ( $dn1[ 'nb1' ] > 0 ) {
		if ( isset( $_SESSION[ 'username' ] )and getAccessLevel( $_SESSION[ 'username' ] ) == "Administrator" ) {
			//Allows a user to delete a category 
			$nb_new_pm = mysql_fetch_array( mysql_query( 'select count(*) as nb_new_pm from pm where ((user1="' . $_SESSION[ 'userID' ] . '" and user1read="no") or (user2="' . $_SESSION[ 'userID' ] . '" and user2read="no")) and id2="1"' ) );
			$nb_new_pm = $nb_new_pm[ 'nb_new_pm' ];
			?>
			<div class="box">
				<div class="box_left">
					<a href="discussIndex.php">Forum Home</a> &gt;
					<?php echo htmlentities($dn1['name'], ENT_QUOTES, 'UTF-8'); ?> &gt; Delete the category
				</div>
				<div class="box_right">
					<a href="list_pm.php">Your messages(<?php echo $nb_new_pm; ?>)</a> -
					<a href="profile.php">
						<?php echo htmlentities($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>
					</a>
				</div>
				<div class="clean"></div>
			</div>
			<?php
			if ( isset( $_POST[ 'confirm' ] ) ) {
				if ( mysql_query( 'delete from categories where id="' . $id . '"' )and mysql_query( 'delete from topics where parent="' . $id . '"' )and mysql_query( 'update categories set position=position-1 where position>"' . $dn1[ 'position' ] . '"' ) ) {
					?>
					<div class="message">The category and it topics have successfully been deleted.<br/>
						<a href="discussIndex.php">Go to forum home</a>
					</div>
					<?php
				}
				// shows message to user for confirmation of deletion with option yes/no or displays that an error occured whilst deleting
				else {
					echo 'An error occured while deleting the category and it topics.';
				}
			}
			else {
				?>
				<form action="delete_category.php?id=<?php echo $id; ?>" method="post">
					Are you sure you want to delete this category and all its topics?
					<input type="hidden" name="confirm" value="true"/>
					<input type="submit" value="Yes"/> <input type="button" value="No" onclick="javascript:history.go(-1);"/>
				</form>
				<?php
			}
		}
		//admin login restriction messages
		else {
			echo '<h2>You must be logged as an administrator to access this page: <a href="login.php">Login</a> - <a href="register.php">Sign Up</a></h2>';
		}
	}
	//admin login restriction messages
	else {
		echo '<h2>You must be logged as an administrator to access this page: <a href="login.php">Login</a> - <a href="register.php">Sign Up</a></h2>';
	}
}
else {
	echo '<h2>The category you want to delete does not exist.</h2>';
}

// Display footer
echo makeFooter();
?>