<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Edit Profile");

// If user is logged in, start main body and request their profile details from the database
if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
	echo startMain();
		$username = $_SESSION['username'];
		$stmt = $db->query( "SELECT * FROM `users` WHERE `username` = '$username'");
		$obj = $stmt->fetchObject();
	?>
	<head>
		<script src="jquery-3.4.0.min.js"></script>
	</head>
				<h1 style='text-align: center;'>Edit Your Profile</h1>
				<form name="user" method="post" action="profileProcess.php" enctype="multipart/form-data">
					<!-- Display essential information to edit, except for username which is readonly !-->
					<fieldset>
						<label for="username">Username:</label>
						<input type="text" name="username" style="font-weight: bold;" value="<?php echo $obj->username; ?>" readonly><br /><br />
						<label for="firstName">First Name:</label><br />
						<input type="text" name="firstName" value="<?php echo $obj->firstName; ?>"><br /><br />
						<label for="surname">Surname:</label><br />
						<input type="text" name="surname" value="<?php echo $obj->surname; ?>"><br /><br />
						<label for="email">Email:</label><br />
						<input type="email" name="email" value="<?php echo $obj->email; ?>"><br /><br />
						<label for="password">Password:</label><br />
						<input type="password" name="password" id="password" placeholder="Click here to enter a new password, leave blank to retain current password"><br />
						<p id="strength_human"></p>
					</fieldset>
					<br />
					<fieldset>
						<?php
						// Display user image, if available, regardless of which logged user accesses the page
						if ($obj->imageURL!=null){
							echo "<p>Current image:</p>";
							echo "<img class='profileSocial' src=".$obj->imageURL." alt=".$obj->username."/>";
							echo "<br /><br />";
							echo "<label for='clearImage'>Clear current image:</label>";
							echo "<input type='checkbox' name='clearImage' class='clearImage' role='button' style='margin-left:10px;'><br /><br />";
							echo "<p class='imageSelect'>Choose new profile image:</p>";
						}
						?>
						<br />
						<label for="file" class="imageSelect">Image:</label>
						<input type="file" class="imageSelect" name="image" /><br /><br />
					</fieldset>
					<br />
					<!-- Display optional information to edit !-->
					<fieldset>
						<label for="bio">Bio:</label><br />
						<textarea name="bio" oninput='this.style.height = "";this.style.height = this.scrollHeight + "px"'><?php echo $obj->bio; ?></textarea><br /><br />
						<div style="width:90%;">
						<label for="facebook">Facebook:<br />www.facebook.com/</label>
						<input type="text" name="facebook" style="width:80%;float:right;" value="<?php echo $obj->facebook; ?>">
						</div><br />
						<div style="width:90%;">
						<label for="twitter">Twitter:<br />www.twiter.com/</label>
						<input type="text" name="twitter" style="width:80%;float:right;" value="<?php echo $obj->twitter; ?>">
						</div><br />
						<div style="width:90%;">
						<label for="instagram">Instagram:<br />www.instagram.com/</label>
						<input type="text" name="instagram" style="width:80%;float:right;" value="<?php echo $obj->instagram; ?>">
						</div><br /><br />
						<label for="display">Display your bio and social media details to other users?:  </label>
						<input type="checkbox" name="display" style="margin-left:10px;" <?php if($obj->display !== '0') echo 'checked="checked"';?> value="1"><br /><br />
					</fieldset>
					<br />
					<div class="wrapper">
						<input type="submit" name="update" value="Update Profile">
						<?php
						// Display delete profile option, unless it is main administrator profile. This is to ensure that there is always at least one administrator level profile
						if ($obj->userID !=1) {
							echo "<input type='submit' name='delete' value='Delete Profile' style='background-color: #9e1e20; font-weight: bold'>";
						}
						?>
				</form>
						<p>Return to <a href='profile.php'>your profile</a></p>
					</div>
<?php
}

// If user is not logged in, start main body and display redirection message
else {
	echo startSmallMain();
				echo "<h1>Page Not Accessible</h1>";
				echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>
<script>
// Password strength text prompt
function scorePassword(pass) {
    var score = 0;
    if (!pass)
        return score;

    // award every unique letter until 5 repetitions
    var letters = new Object();
    for (var i=0; i<pass.length; i++) {
        letters[pass[i]] = (letters[pass[i]] || 0) + 1;
        score += 5.0 / letters[pass[i]];
    }

    // bonus points for mixing it up
    var variations = {
        digits: /\d/.test(pass),
        lower: /[a-z]/.test(pass),
        upper: /[A-Z]/.test(pass),
        nonWords: /\W/.test(pass),
    }

    variationCount = 0;
    for (var check in variations) {
        variationCount += (variations[check] == true) ? 1 : 0;
    }
    score += (variationCount - 1) * 10;

    return parseInt(score);
}

function checkPassStrength(pass) {
    var score = scorePassword(pass);
    if (score > 80)
        return "\nPassword Strength: Strong\n";
    if (score > 60)
        return "\nPassword Strength: Good\n";
    if (score >= 30)
        return "\nPassword Strength: Weak";

    return "\nPassword Strength: Weak\n";
}

$(document).ready(function() {
    $("#password").on("keypress keyup keydown", function() {
        var pass = $(this).val();
        $("#strength_human").text(checkPassStrength(pass));
        $("#strength_score").text(scorePassword(pass));
    });
});
</script>