<?php
// Include header, menu and other functions, plus config
require_once( "functions.php" );
require_once( "config.php" );

// Set session path
$studentID = getStudentID();
ini_set( "session.save_path", "/home/" . $studentID . "/sessionData" );

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader( "Blogbusters | New Category" );

//This page lets users create a new category
include( 'config.php' );
if ( isset( $_SESSION[ 'username' ] ) and getAccessLevel( $_SESSION[ 'username' ] ) == "Administrator" ) {
	?>
		<div class="content">
			<?php
			//Displays links at the top of the page to be redirected to Forum Home, Messages and also shows what user is logged in
			$nb_new_pm = mysql_fetch_array( mysql_query( 'select count(*) as nb_new_pm from pm where ((user1="' . $_SESSION[ 'userID' ] . '" and user1read="no") or (user2="' . $_SESSION[ 'userID' ] . '" and user2read="no")) and id2="1"' ) );
			$nb_new_pm = $nb_new_pm[ 'nb_new_pm' ];
			?>
			<div class="box">
				<div class="box_left">
					<a href="discussIndex.php">Forum Home</a> &gt; New Category
				</div>
				<div class="box_right">
					<a href="list_pm.php">Your messages(<?php echo $nb_new_pm; ?>)</a> -
					<a href="profile.php">
						<?php echo htmlentities($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>
					</a>
				</div>
				<div class="clean"></div>
			</div>
			<?php
			//inserts category into the discussion board, followed by user message of confirmation
			if ( isset( $_POST[ 'name' ], $_POST[ 'description' ] )and $_POST[ 'name' ] != '' ) {
				$name = $_POST[ 'name' ];
				$description = $_POST[ 'description' ];
				if ( get_magic_quotes_gpc() ) {
					$name = stripslashes( $name );
					$description = stripslashes( $description );
				}
				$name = mysql_real_escape_string( $name );
				$description = mysql_real_escape_string( $description );
				if ( mysql_query( 'insert into categories (id, name, description, position) select ifnull(max(id), 0)+1, "' . $name . '", "' . $description . '", count(id)+1 from categories' ) ) {
					?>
			<div class="message">The category has successfully been created.<br/>
				<a href="discussIndex.php">Go to Forum Home</a>
			</div>
			<?php
					// Error message to inform user that the category could not be deleted
			} else {
				echo 'An error occured while creating the category.';
			}
			} else {
				?>
			<form action="new_category.php" method="post">
				<label for="name">Name</label><br/><input type="text" name="name" id="name"/><br/>
				<label for="description">Description</label>(html enabled)<br/>
				<textarea name="description" id="description" cols="70" rows="6"></textarea><br/>
				<input type="submit" value="Create"/>
			</form>
			<?php
			}
			?>
		</div>
	<?php
	//User restriction displaying user message and a link to login
} else {
	echo '<h2>You must be logged as an administrator to access this page: <a href="login.php">Login</a> - <a href="register.php">Sign Up</a></h2>';
	echo getAccessLevel( $_SESSION[ 'username' ] );
}

echo makeFooter();
?>