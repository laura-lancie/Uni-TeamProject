  This folder should be uploaded as part of the website but does not contain any images until a user adds their profile image to it
