<style>
formDisplay {
	border: black 1px solid; 
	text-align:center;
}

formlink {
	text-align:center;
}

</style>
<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display header
echo makeHeader("Blogbusters | User comments");
echo startMain("User comments Page");
	
	//Link to send user back to the review page 
	echo "<formlink><p>Go back to <a href='reviews.php'>reviews</a></p></form>";
	
		//Select data from 'comments' table 
		$query = "SELECT author FROM reviews"; 
		
		
		$displayComment = $db->query($query);	
		while	($commentPost = $displayComment->fetchObject() ) {
			$author = $commentPost->author; 
		}
		$sql = "SELECT userComment, rating FROM comment";
		
		$displayComment = $db->query($sql);		

		while	($commentPost = $displayComment->fetchObject() ) {
			$userComment = $commentPost->userComment;
			$rating = $commentPost->rating;
				
				//Echo form to show data from 'comments' table 
					if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
						echo "<form>";
						echo "<p>Author: $author</p>";
						echo "<p>Comment: $userComment</p>";
						echo "<p>Rating: $rating/10</p>";
						echo "</form>";
					}
					else {
						echo "You must be logged in!"; 
					}
					
				//If the user access level is 'Administrator' then display the delete form
				if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
				if (getAccessLevel($_SESSION['username'])=="Administrator") {
			
					echo "<form method='post' action='deleteComment.php'>";
					echo "<input type='text' name='userComment' style='display:none' value=$userComment readonly />";
					echo "<input type='submit' name='submit' value='Delete Comment' />";
				}
				echo "</form>";
				
				}
		}		

//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>