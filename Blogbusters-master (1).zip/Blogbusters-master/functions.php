<?php
// Global parameters
static $studentEmail = "david.mcdowell@northumbria.ac.uk"; // Student email to send confirmation email to user on registration
static $directory = "KV6002"; // Name of main folder on NewNUMySpace that contains pages

// Call studentID
function getStudentID() {
	static $studentID = "unn_w18029630"; // Student ID for access to NewNUMySpace
	return $studentID;
}

// Call studentPass
function getStudentPass() {
	static $studentPass = "NUni18"; // Student password for access to NewNUMySpace
	return $studentPass;
}

// Connect to database
function getConnection() {
	$studentID = getStudentID();
	$studentPass = getStudentPass();
	$db = new PDO(
	"mysql:host=localhost;dbname=".$studentID,$studentID,$studentPass);
	return $db;
}

// Define header elements
function makeHeader($title) {
	$menuItem = null;
	
	// Select navigation menu based on user access level
	if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
		if (getAccessLevel($_SESSION['username'])=="Administrator") {
			$menus = simpleXML_load_file('menuAdmin.xml');
		}
		else {
			$menus = simpleXML_load_file('menuUser.xml');
		}
	}
	
	// Select guest menu for users not logged in
	else {
		$menus = simpleXML_load_file('menuGuest.xml');
	}
	
	// Display highlight on active menu item
	foreach ($menus as $menu) {
		$activePage = strtok(basename($_SERVER["REQUEST_URI"]),'?');
		if ($activePage == "register.php" || $activePage == "registerProcess.php" || $activePage == "loginProcess.php" || $activePage == "emailConfirm.php" || $activePage == "forgotPassword.php" || $activePage == "forgotProcess.php" || $activePage == "passwordReset.php") {
			$activePage = "login.php";
		}
		if ($activePage == "profileEdit.php" || $activePage == "profileProcess.php") {
			$activePage = "profile.php";
		}
		if ($activePage == "adminProcess.php" || $activePage == "adminUsers.php" || $activePage == "adminEvents.php") {
			$activePage = "admin.php";
		}
		if ($activePage == "terms.php" || $activePage == "privacyPolicy.php") {
			$activePage = "about.php";
		}
		if ($activePage == "list_pm.php" || $activePage == "list_topics.php" || $activePage == "read_topic.php" || $activePage == "new_pm.php" || $activePage == "new_reply.php" || $activePage == "edit_category.php"  || $activePage == "new_category.php") {
			$activePage = "discussIndex.php";
		}
		if ($activePage == "searchReviews.php" || $activePage == "displayReview.php" || $activePage == "displayComment.php"  || $activePage == "addReview.php"   || $activePage == "editReview.php") {
			$activePage = "reviews.php";
		}
		if($activePage==$menu->link) {
			$menuItem .= "<li>";
			$menuItem .= "<a class='active' href='$menu->link'>$menu->text</a>";
			if (count($menu->menus)>0) {
				$menuItem .= "<ul class='dropdown'>";
				foreach ($menu->menus->children() as $menu) {
					$menuItem .= "<li><a href='$menu->link'>$menu->text</a></li>";
				}
				$menuItem .= "</ul>";
			}
			$menuItem .= "</li>";
		}
		else {
			$menuItem .= "<li>";
			$menuItem .= "<a href='$menu->link'>$menu->text</a>";
			if (count($menu->menus)>0) {
				$menuItem .= "<ul class='dropdown' >";
				foreach ($menu->menus->children() as $menu) {
					$menuItem .= "<li><a href='$menu->link'>$menu->text</a></li>";
				}
				$menuItem .= "</ul>";
			}
			$menuItem .= "</li>";
		}
	}
	
	// Create header layout
	$headContent = <<<HEAD
		<!DOCTYPE html>
		<html lang="en">
		<head>
			<meta charset="utf-8" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=true" />
			<title>$title</title>
			<link rel="stylesheet" type="text/css" href="style.css" />
		</head>
		<body>
			<header>
				<a href="index.php" class="logo"><img id="logo" alt="Logo" src="images/logo.png" width="210" height="75"></a>
				<label for="showMenu" class="showMenu">Menu</label>
				<input type="checkbox" id="showMenu" role="button">
				<nav>
					<ul>
						$menuItem
					</ul>
				</nav>
			</header>
HEAD;
		$headContent .="\n";
		return $headContent;
}

// Start main body content
function startMain() {
	$mainContent = <<< MAIN
		<main>
			<div class="wrapper">
				<div class="largeContainer">
MAIN;
	return $mainContent;
}

// Start main body content when there is only a user message displayed
function startSmallMain() {
	$mainContent = <<< MAIN
		<main>
			<div class="wrapper">
				<div class="smallContainer">
MAIN;
	return $mainContent;
}

// End main body content
function endMain() {
			echo "</div>";
		echo "</div>";
	echo "</main>";
}

// Define footer content
function makeFooter() {
	$footContent = <<< FOOT
		<footer>
			<p><a href="terms.php">Terms and Conditions</a> | <a href="privacyPolicy.php">Privacy Policy</a> | &copyBlogbusters</p>
		</footer>
		</body>
		</html>
FOOT;
		return $footContent;
}
// Search bar
function searchBar() {
echo "<form action='searchReviews.php' method='post'>";
	echo "<input type='text' name='search' placeholder='Search our reviews for a movie...' onkeydown='searchq();'/>";
	echo "<input type='submit' value='Search'/>";
echo "</form>";
echo "<br />";
}

// Function to display user's access level as a string
function getAccessLevel($user) {
	$username = $user;
	$db = getConnection();
	$stmt = $db->query( "SELECT `accessLevel` FROM `userAccess` INNER JOIN `users` ON userAccess.accessID = users.access WHERE `username` = '$username'");
	$obj = $stmt->fetchObject();
	return $obj->accessLevel;
}
?>