<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display header 
echo makeHeader("Blogbusters | Edit Reviews");
echo startMain("Edit Reviews Page");

//defining variables 
if(isset($_POST['update']))
{    
    $reviewID = $_POST['reviewID'];
    $reviewName=$_POST['reviewName'];
    $description=$_POST['description'];
    $review=$_POST['review'];  
	$author=$_POST['author']; 
	
       
        //updating the table
        $sql = "UPDATE reviews SET reviewName=:reviewName, description=:description, review=:review, author=:author WHERE reviewID=:reviewID";
        $query = $db->prepare($sql);
                
        $query->bindparam(':reviewID', $reviewID);
        $query->bindparam(':reviewName', $reviewName);
        $query->bindparam(':description', $description);
        $query->bindparam(':review', $review);
		$query->bindparam(':author', $author);
		$query->execute();
}
	echo "You have edited the review! Return to <a href='reviews.php'>Reviews</a> to see the new review!";
?>
<?php
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>