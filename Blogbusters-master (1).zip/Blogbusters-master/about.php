<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | About Us");

// Start main page body
echo startMain();
?>
	<div class="wrapper">
		<div id="aboutImg">
			<img src="images/logo.png" style="max-width:100%;" />
		</div>
		<div id="aboutMain">
			<p>Blogbusters is a community of movie reviewers in the North East of England. We arrange movie nights and other events for our members on a regular basis and offer a place for movie enthusiast to share their thoughts!</p>
			<p>If you'd like to become a member, <a href="register.php">click here</a> to get started!</p>
			<?php
			if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']) {
				echo "<p>If you would like to post reviews on our site, <a href='new_pm.php'>contact</a> our administrator</p>";
			}
			else {
				echo "<p>If you would like to post reviews on our site, <a href='login.php'>log in</a> or <a href='register.php'>sign up</a> and message our administrator on our discussion board</p>";
			}
			?>
			<div class="wrapper">
				<div class="socialContainer" style="width:32%;">
					<a href="https://www.facebook.com/blogbustersUK"><img class="profileSocial" src="images/fb-logo.png" alt="facebook" /></a>
					</p><a href="https://www.facebook.com/blogbustersUK">Our Facebook</a></p>
				</div>
				<div class="socialContainer" style="width:32%;">
					<a href="https://www.twitter.com/blogbustersUK"><img class="profileSocial" src="images/twitter-logo.png" alt="twitter" /></a>
					</p><a href="https://www.twitter.com/blogbustersUK">Our Twitter</a></p>
				</div>
				<div class="socialContainer" style="width:32%;">
					<a href="https://www.instagram.com/blogbustersUK"><img class="profileSocial" src="images/instagram-logo.png" alt="instagram" /></a>
					</p><a href="https://www.instagram.com/blogbustersUK">Our Instagram</a></p>
				</div>
			</div>
		</div>
	</div>
<?php	
// End main body
echo endMain();

// Display footer
echo makeFooter();
?>