<?php 
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display header 
echo makeHeader("Blogbusters | Delete Review");

	//Request the reviewID from 'reviews' table 
	$reviewID = $_REQUEST['reviewID'];
	
	//Delete data from the 'reviews' table where reviewID is matched 
	$sql = "DELETE FROM `reviews` WHERE `reviewID` = '$reviewID'";
	
		//Prepare the query and execute 
		$stmt = $db->prepare($sql);
		$stmt->execute();
		
			//Display the link when the review has been deleted 
			echo "<p>The Review has been deleted</p>";
			echo "<p>Return to the <a href='reviews.php'>reviews</a> page</p>";
		
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>