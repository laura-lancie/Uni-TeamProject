<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display header 
echo makeHeader("Blogbusters | Edit Reviews");
echo startMain("Edit Reviews Page");

?>
<?php

//Getting reviewID 
$reviewID = $_REQUEST['reviewID'];

 
	//selecting data associated with reviewID
	$sql = "SELECT * FROM reviews WHERE reviewID=:reviewID";
	$query = $db->prepare($sql);
	$query->execute(array(':reviewID' => $reviewID));
 
	while($row = $query->fetch(PDO::FETCH_ASSOC))
	{
		$reviewName = $row['reviewName'];
		$description = $row['description'];
		$review = $row['review'];
		$author = $row['author'];
	}
?>
		<!--Update form!-->
		
		<form id="edit" name="edit" action ="editPage.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
		<label for="author">Author:</label><br />
		<input type="text" name="author" value="<?php echo $author;?>" readonly><br/><br/>
		<label for="reviewName">Reviewname:</label><br />
		<input type="text" name="reviewName" value="<?php echo $reviewName;?>"><br/><br/>
		<label for="description">Description:</label><br />
		<input type="text" name="description" value="<?php echo $description;?>"><br/><br/>
		<label for="review">Review:</label><br />
		<input type="text" name="review" value="<?php echo $review;?>"><br/><br/>
		<input type="hidden" name="reviewID" value=<?php echo $_REQUEST['reviewID'];?></br></br>
		<input type="submit" name="update" value="update">
		</form> 
		
<?php
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>
<script>
//form validation
function validateForm() {
		    var x = document.forms["edit"]["reviewName"].value;
    if (x == "") {
        alert("Review name must be filled out");
        return false;
    }
    var x = document.forms["edit"]["reviewName"].value;
    if (x == "") {
        alert("Review name must be filled out");
        return false;
    }
	    var x = document.forms["edit"]["description"].value;
    if (x == "") {
        alert("Description must be filled out");
        return false;
    }
		    var x = document.forms["edit"]["review"].value;
    if (x == "") {
        alert("Review must be filled out");
        return false;
    }

}
</script>
<script>
function textFunction() {
  document.getElementById("description").maxLength = "100";
}
</script>
<script>
function textFunction() {
  document.getElementById("review").maxLength = "1000";
}
</script>