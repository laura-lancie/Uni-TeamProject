<style>
#addComment {
	width:100%;
	border: black 3px solid; 
	text-align:center;
}
</style>
<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display Header 
echo makeHeader("Blogbusters | Review");
echo startMain("Review Page");

// Call search bar
echo searchBar();
	
	//Request the reviewID from 'reviews' table 
	$reviewID = $_REQUEST['reviewID'];
	
	//Selecting data from the 'reviews' table 
	$sql = "SELECT reviewID, reviewName, author, review, imageURL FROM reviews WHERE `reviewID` = '$reviewID'";

		//Start posting query 
		$displayReview = $db->query($sql);		
	
			//Fetch data when the results match the variables
			while ( $userReview = $displayReview->fetchObject() ) {
				$reviewID = $userReview->reviewID;
				$reviewName = $userReview->reviewName;
				$author = $userReview->author;
				$review = $userReview->review;
				$imageURL = $userReview->imageURL;
				
				//Post review details
				if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
					echo "<img src='$imageURL' style='width:100%;height:100%;'>";
					echo "<form method='post' action = 'profile.php'>";
					echo "<input type='submit' name='username' class='profileLink' value='$author'>";
					echo "<p>Review name: $reviewName</p>";
					echo "$review</p>";
					echo "</form>";
	}
		else {
			echo "You must be signed in!";
		}
				}
	
?>
</br></br>
<?php 
?>
				<?php

					//If the user is logged in, display the comment and form
					if (isset($_SESSION['logged-in']) && $_SESSION['logged-in']){
						echo"<form id='addComment' name='addComment' action ='addComment.php' method='post' onsubmit='return validateForm()'>";
						echo "<label for='userComment'>Add your own comment:</label></br>";
						echo "<input type='text' placeholder='Add a comment...' name='userComment'/></br></br>";
						
						echo "<label for='rating'>I Rate this movie</label>";
						echo "<select name='rating'></br>";
							echo "<option value='1'>1</option>";
							echo "<option value='2'>2</option>";
							echo "<option value='3'>3</option>";
							echo "<option value='4'>4</option>";
							echo "<option value='5'>5</option>";
							echo "<option value='6'>6</option>";
							echo "<option value='7'>7</option>";
							echo "<option value='8'>8</option>";
							echo "<option value='9'>9</option>";
							echo "<option value='10'>10</option>
						</select>";
							echo "<label for='rating'>&nbsp;/10</label></br></br></br>";
							echo "<input type='submit' name='submit' value='submit'></br></br>";
							echo "<a href='displayComment.php'>Check out all our comments!</a>";
					}
?>
<?php
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>
<script>
//Form validation 
function validateForm() {
    var x = document.forms["addComment"]["userComment"].value;
    if (x == "") {
        alert("You cannot submit a blank comment");
        return false;
    }
}
</script>