<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Reset Password");

// If email is in URL
if ( isset($_GET['email']) || isset($_GET['tempPassword']) || isset($_POST["resetPassword"]) ) {
	if (isset($_GET['email']) && isset($_GET['tempPassword'])) {
		$email = $_GET['email'];
		$tempPassword = $_GET['tempPassword'];
			
		// Request details from database
		$stmt = $db->query( "SELECT `username` FROM `users` WHERE `email` = '$email' AND `tempPassword` = '$tempPassword'");
		$obj = $stmt->fetchObject();
			
		// If a result is found, process the below
		if($obj != null) {
			// Start main page body
			echo startSmallMain();
						echo "<h1>Reset Password</h1>";
						echo "<p>".$obj->username.", please set a new password below:</p>";
						echo "<form name='resetPassword' method='post' action=".$_SERVER['PHP_SELF'].">";
							echo "<fieldset>";
								echo "<br />";
								echo "<input type='hidden' name='email' value=".$email.">";
								echo "<label for='password'>Password:</label><br />";
								echo "<input type='password' name='password' required><br /><br />";
								echo "<label for='passwordConfirm'>Password:</label><br />";
								echo "<input type='password' name='passwordConfirm' required><br /><br />";
								echo "<div style='width: 90%;'>";
									echo "<input type='submit' name='resetPassword' value='Change Password' style='float: right;'>";
								echo "</div>";
								echo "<br /><br />";
							echo "</fieldset>";
						echo "</form>";
		}
			
		// If email is not found in the database table
		else {
			// Start main page body
			echo startSmallMain();
						echo "<h1>Email not found</h1>";
						echo "<p>The email provided does not match our records</p>";
						echo "<p>Please try the link provided again or return to <a href='forgotPassword.php'>forgotten password</a></p>";
		}
	}

	// If the change password button is clicked, process the below code
	if(isset($_POST["resetPassword"])){
				
		// Request data from confirmation table
		$email = $_REQUEST['email'];
		$password = $_REQUEST['password'];
		$passwordConfirm = $_REQUEST['passwordConfirm'];
				
		// If the current passwords provided match each other and match the password held on the database, action the below processes
		if ($password == $passwordConfirm) {

			// Create salt, hash password and clear temp password
			$options = ['cost'=>12,];
			$newPassword = password_hash($password,PASSWORD_DEFAULT,$options);
			$tempPassword = null;

			// Prepare the SQL statement
			$sql = "UPDATE `users` SET `password`= :password, `tempPassword`= :tempPassword WHERE `email` = '$email'";
						
			// Prepare the values
			$stmt = $db->prepare($sql);
			$stmt->bindParam(':password', $newPassword, PDO::PARAM_STR);
			$stmt->bindParam(':tempPassword', $tempPassword, PDO::PARAM_STR);

			// Execute the statement
			$stmt->execute();
			
			// Start main page body
			echo startSmallMain();
							echo "<h1>Password Changed</h1>";
						
							// Return message to the user that the profile has been updated
							echo "<p>Your password has been changed!</p>";
							echo "<p>Return to <a href='login.php'>log in</a></p>";
		}
				
		// If the provided current passwords do not match, return a message to the user to return to the email link
		else {
		// Start main page body
			echo startSmallMain();
						echo "<h1>Update Failure</h1>";
						echo "<p>Provided passwords do not match</p>";
						echo "<p>Please follow the link from the forgotten password email again</p>";
		}
	}
}

// If no details have been passed, display redirection message
else {
	// Start main page body
	echo startSmallMain();
				echo "<h1>Page Not Accessible</h1>";
				echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>