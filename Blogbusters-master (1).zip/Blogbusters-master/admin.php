<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Admin");

// If logged in with administration rights, display content
if (isset($_SESSION['logged-in']) && $_SESSION['logged-in'] && getAccessLevel($_SESSION['username']) == "Administrator"){
	// Start main page body
	echo startSmallMain();
?>
			<!-- Display message redirecting administrator to either user or event admin !-->
			<h1 style="text-align: center;">Admin</h1>
			<p>To view and moderate user accounts <a href="adminUsers.php">click here</a></p>
			<p>To view moderate events <a href="adminEvents.php">click here</a></p>
<?php
}
// If not logged in or insufficient access rights, display redirection message
else {
	// Start main page body
	echo startSmallMain();
				echo "<h1>Page Not Accessible</h1>";
				echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>