<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Retrieve the session
$_SESSION = array();

// Destroy the session
session_destroy();

// Return to the home page and finish process
header("location:index.php");
exit();
?>