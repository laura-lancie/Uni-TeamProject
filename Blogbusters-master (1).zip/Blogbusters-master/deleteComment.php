 <?php 
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display header 
echo makeHeader("Blogbusters | Delete Comment");
			
			//Request userComment from 'comment' table 
			$userComment = $_REQUEST['userComment'];
			
			//Delete query where userComment equals Usercomment variable 
			$sql = "DELETE FROM `comment` WHERE `userComment` = '$userComment'";
			$stmt = $db->prepare($sql);
			$stmt->execute();
				
				//Display message that the comment has been deleted and a link to return to displayComment page 
				echo "<p>The comment has been deleted</p>";
				echo "<p>Return to the <a href='displayComment.php'>comments</a> page</p>";
		
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter(); 
?> 