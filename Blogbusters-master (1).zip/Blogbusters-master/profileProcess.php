<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Include PHPMailer functionality
use PHPMailer\PHPMailer\PHPMailer;

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Amend Profile");

	// If details have been passed from the previous page, process the below
	if (isset($_POST["update"]) || isset($_POST["updateConfirm"]) || isset($_POST["delete"]) || isset($_POST["deleteConfirm"])) {

		// If the update profile input button was pressed on the edit profile page, process the below
		if (isset($_POST["update"])) {
					
				$username = $_SESSION['username'];
				
				// If new email has been provided, change confirmation status
				$stmt = $db->query( "SELECT `email` FROM `users` WHERE `username` = '$username'");
				$obj = $stmt->fetchObject();
				$currentEmail = $obj->email;
				$newEmail = $_REQUEST['email'];
				if ($currentEmail != $newEmail) {
					$confirmEmail = 0;
					$confirmMsg = "<br /><p><strong>Note:</strong> changing your email will require it to be validated. Please check your inbox</p>";
				}
				else {
					$confirmEmail = 1;
					$confirmMsg = "";
				}
				
				// If no new password has been provided, use existing password
				if ($_REQUEST['password'] == null) {
					$stmt = $db->query( "SELECT `password` FROM `users` WHERE `username` = '$username'");
					$obj = $stmt->fetchObject();
					$newPassword = $obj->password;
				}
				
				// If a new password has been provided, encrypt using a salt
				else {
					$options = ['cost'=>12,];
					$newPassword = password_hash($_REQUEST['password'],PASSWORD_DEFAULT,$options);
				}

				// If there has been no new image file has been provided, use existing file path (which could be blank)
				if (empty($_FILES["image"]["name"])) {
					// If the clear image button has been clicked, remove image URL
					if (isset($_REQUEST['clearImage'])) {
						$imageURL = "";
					}
					else {
						$stmt = $db->query( "SELECT `imageURL` FROM `users` WHERE `username` = '$username'");
						$obj = $stmt->fetchObject();
						$imageURL = $obj->imageURL;
					}
				}
				
				// If a new image file has been provided, move it to the appropriate folder
				else {
					$imageURL = "userImages/" . $_FILES["image"]["name"];
					move_uploaded_file($_FILES["image"]["tmp_name"], $imageURL);
				}

				// If the checkbox for displaying bio and social media details is blank, add a zero value to the database
				if (!isset($_REQUEST['display'])) {
					$display = 0;
				}
				
				// If the display checkbox is populated, bring forward the value
				else {
					$display = $_REQUEST['display'];
				}
				
				// Start main page body
				echo startSmallMain();
						echo "<h1>Update Profile</h1>";
						
						// Create form for users to confirm the changes
						if ($_REQUEST['password'] != null) {
							echo "<p>Enter your current password to confirm the changes:</p>";
						}
						else {
							echo "<p>Enter your password to confirm the changes:</p>";
						}
						echo "<form name='update' method='post' action=".$_SERVER['PHP_SELF'].">";
							echo "<fieldset>";
						
								// Bring previous form values forward to new form as hidden fields
								echo "<input type='hidden' name='firstName' value=".$_REQUEST['firstName'].">";
								echo "<input type='hidden' name='surname' value=".$_REQUEST['surname'].">";
								echo "<input type='hidden' name='email' value=".$_REQUEST['email'].">";
								echo "<input type='hidden' name='emailConfirm' value=".$confirmEmail.">";
								echo "<input type='hidden' name='newPassword' value=".$newPassword.">";
								echo "<input type='hidden' name='imageURL' value=".$imageURL.">";
								echo "<input type='hidden' name='bio' value='".$_REQUEST['bio']."'>";
								echo "<input type='hidden' name='display' value=".$display.">";
								echo "<input type='hidden' name='facebook' value=".$_REQUEST['facebook'].">";
								echo "<input type='hidden' name='twitter' value=".$_REQUEST['twitter'].">";
								echo "<input type='hidden' name='instagram' value=".$_REQUEST['instagram'].">";
								
								// Display password and password confirmation fields, along with submit button
								if ($_REQUEST['password'] != null) {
									echo "<label for='password'>Current Password:</label><br />";
								}
								else {
									echo "<label for='password'>Password:</label><br />";
								}
								echo "<input type='password' name='password' required><br /><br />";
								
								if ($_REQUEST['password'] != null) {
									echo "<label for='passwordConfirm'>Confirm Current Password:</label><br />";
								}
								else {
									echo "<label for='passwordConfirm'>Confirm Password:</label><br />";
								}
								echo "<input type='password' name='passwordConfirm' required><br /><br />";
								echo "<div style='width: 90%;'>";
								echo "<input type='submit' name='updateConfirm' value='Update Profile' style='float: right;'>";
								echo "</div>";
								echo $confirmMsg;
							echo "</fieldset>";
						echo "</form>";
						echo "<p style='text-align: center;'>Return to <a href='profileEdit.php'>edit profile</a></p>";
			}

			// If the confirm update button is clicked, process the below code
			if(isset($_POST["updateConfirm"])){
				
				$username = $_SESSION['username'];
				
				// Select all data from users table in the database based on the session username
				$stmt = $db->query( "SELECT * FROM `users` WHERE `username` = '$username'");
				$obj = $stmt->fetchObject();
				
				// Request data from confirmation table
				$password = $_REQUEST['password'];
				$passwordConfirm = $_REQUEST['passwordConfirm'];
				
				$updateFirstName = $_REQUEST['firstName'];
				$updateSurname = $_REQUEST['surname'];
				$updateEmail = $_REQUEST['email'];
				$emailConfirm = $_REQUEST['emailConfirm'];
				$updatePassword = $_REQUEST['newPassword'];
				$updateImageURL = $_REQUEST['imageURL'];
				$updateBio = $_REQUEST['bio'];
				$updateDisplay = $_REQUEST['display'];
				$updateFB = $_REQUEST['facebook'];
				$updateTwitter = $_REQUEST['twitter'];
				$updateInstagram = $_REQUEST['instagram'];
				
				// If the current passwords provided match each other and match the password held on the database, action the below processes
				if (password_verify($password,$obj->password)&& $password == $passwordConfirm) {
			
					// Start main page body
					echo startSmallMain();
							echo "<h1>Update Confirmed</h1>";
						
							// Return message to the user that the profile has been updated
							echo "<p>Your profile has been successfully updated!</p>";
							echo "<p>Back to <a href='profile.php'>your profile</a></p>";

					// Prepare the SQL statement
					$sql = "UPDATE `users` SET `firstName`= :firstName, `surname`= :surname, `email`= :email, `password`= :password, `imageURL`= :imageURL, `bio`= :bio, `facebook`= :facebook, `twitter`= :twitter, `instagram`= :instagram, `emailConfirm` = :confirm, `display`= :display WHERE `username` = '$username'";
					
					// Prepare the values
					$stmt = $db->prepare($sql);
					$stmt->bindParam(':firstName', $updateFirstName, PDO::PARAM_STR);
					$stmt->bindParam(':surname', $updateSurname, PDO::PARAM_STR);
					$stmt->bindParam(':email', $updateEmail, PDO::PARAM_STR);
					$stmt->bindParam(':confirm', $emailConfirm, PDO::PARAM_INT);
					$stmt->bindParam(':password', $updatePassword, PDO::PARAM_STR);
					$stmt->bindParam(':imageURL', $updateImageURL, PDO::PARAM_STR);
					$stmt->bindParam(':bio', $updateBio, PDO::PARAM_STR);
					$stmt->bindParam(':facebook', $updateFB, PDO::PARAM_STR);
					$stmt->bindParam(':twitter', $updateTwitter, PDO::PARAM_STR);
					$stmt->bindParam(':instagram', $updateInstagram, PDO::PARAM_STR);
					$stmt->bindParam(':display', $updateDisplay, PDO::PARAM_INT);

					// Execute the statement
					$stmt->execute();
					
					// Prepare the SQL statement
					$sqlDiscuss = "UPDATE `discussUsers` SET `email`= :email, `password`= :password, `avatar`= :imageURL WHERE `username` = '$username'";
					
					// Prepare the values
					$stmtDiscuss = $db->prepare($sqlDiscuss);
					$stmtDiscuss->bindParam(':email', $updateEmail, PDO::PARAM_STR);
					$stmtDiscuss->bindParam(':password', $updatePassword, PDO::PARAM_STR);
					$stmtDiscuss->bindParam(':imageURL', $updateImageURL, PDO::PARAM_STR);

					// Execute the statement
					$stmtDiscuss->execute();
					
					// If new email has been provided, change confirmation status and send new confirmation request
					if ($emailConfirm == 0) {
					
						// Create password salt
						$options = ['cost'=>12,];
						
						// Set confirmation email
						$usernameHash = password_hash($username,PASSWORD_DEFAULT,$options); // Encrypted username
						include_once ("PHPMailer/PHPMailer.php");
						$mail = new PHPMailer();
						$mail->setFrom($studentEmail);
						$mail->addAddress($updateEmail, $username);
						$mail->Subject = "Blogbusters Email Verification";
						$mail->isHTML(true);
						$mail->Body = 	"<p>Hi, $username</p>
										<p>You have changed the email address associated with your Blogbusters account</p>
										<p>Please click on the link below to verify this change:</p>
										<p><a href='http://".$studentID.".newnumyspace.co.uk/".$directory."/emailConfirm.php?email=$updateEmail&username=$usernameHash'>Click here</a></p>";
						$mail->send();
					}
				}
			
				// If the provided current passwords do not match, return a message to the user to return to the edit profile page
				else {
					// Start main page body
					echo startSmallMain();
								echo "<h1>Confirmation Failure</h1>";
								echo "<p>Provided passwords are incorrect. Return to <a href='profileEdit.php'>edit profile</a></p>";
				}
			}

		// If the delete profile input button was pressed on the editProfile page, process the below
		if (isset($_POST["delete"])) {
			
			// Start main page body
			echo startSmallMain();
						echo "<h1>Delete Profile</h1>";
					
						// Create form for users to confirm the profile deletion, including passwords
						echo "<p>Enter your password to confirm the deletion of your profle:</p>";
						echo "<form name='delete' method='post' action=".$_SERVER['PHP_SELF'].">";
						echo "<fieldset>";
						echo "<label for='password'>Password:</label><br />";
						echo "<input type='password' name='password' required><br /><br />";
						echo "<label for='passwordConfirm'>Confirm Password:</label><br />";
						echo "<input type='password' name='passwordConfirm' required><br /><br />";
						echo "<div style='width: 90%;'>";
						echo "<input type='submit' name='deleteConfirm' value='Delete Profile' style='float: right;'>";
						echo "</div>";
						echo "<br /><br />";
						echo "<p style='text-align: center;'><strong><em>Note: </em></strong>This will log you out and return you to the home page</p>";
						echo "</fieldset>";
						echo "</form>";
						echo "<p style='text-align: center;'>Return to <a href='profileEdit.php'>edit profile</a></p>";
		}

			// If the delete profile button is clicked, process the below code
			if(isset($_POST["deleteConfirm"])){
				
				$username = $_SESSION['username'];
				
				$stmt = $db->query( "SELECT * FROM `users` WHERE `username` = '$username'");
				$obj = $stmt->fetchObject();
				
				$password = $_REQUEST['password'];
				$passwordConfirm = $_REQUEST['passwordConfirm'];

				// If the passwords provided match each other and match the password held on the database, action the below processes
				if (password_verify($password,$obj->password)&& $password == $passwordConfirm) {
					
					// Prepare and execute the statement
					$sql = "DELETE FROM `users` WHERE `username` = '$username'";
					$stmt = $db->prepare($sql);
					$stmt->execute();
					
					// Prepare and execute the statement
					$sqlDiscuss = "DELETE FROM `discussUsers` WHERE `username` = '$username'";
					$stmtDiscuss = $db->prepare($sqlDiscuss);
					$stmtDiscuss->execute();
					
					// Log the user out of the website and return them to the home page
					$_SESSION = array();
					session_destroy();
					header("location:index.php");
					exit();
				}
			
				// If the provided passwords do not match, return a message to the user to return to the edit profile page
				else {
					// Start main page body
					echo startSmallMain();
								echo "<h1>Confirmation Failure</h1>";
								echo "<p>Provided passwords are incorrect. Return to <a href='profileEdit.php'>edit profile</a></p>";
				}
			}
	}
	
	// If no details have been passed, display redirection message
	else {
		// Start main page body
		echo startSmallMain();
					echo "<h1>Page Not Accessible</h1>";
					echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
	}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>