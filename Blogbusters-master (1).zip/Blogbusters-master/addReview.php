 <?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

//Display header
echo makeHeader("Blogbusters | Add Reviews");
echo startMain("Add Reviews Page");
	
	//Request the files to insert into 'reviews'
	if(isset($_REQUEST['author']) && isset($_REQUEST['reviewName'])&& isset($_REQUEST['description'])&& isset($_REQUEST['review'])){
		$author = $_REQUEST['author'];
		$reviewName = $_REQUEST['reviewName']; 
		$description = $_REQUEST['description'];
		$review = $_REQUEST['review'];
		
	//Select and update Image (Author of image code @David McDowell)
	if (empty($_FILES["image"]["name"])) {
		$stmt = $db->query( "SELECT `imageURL` FROM `reviews`");
		$obj = $stmt->fetchObject();
		$updateImageURL = $obj->imageURL;
	}
	else {
			$updateImageURL = "userImages/" . $_FILES["image"]["name"];
			move_uploaded_file($_FILES["image"]["tmp_name"], $updateImageURL);
		}
		
		echo "The review has been added! please return to <a href='reviews.php'>reviews</a> to see the added review";
		echo "</br>"; 	echo "</br>"; 	echo "</br>"; 	
	}
	
		//Query to insert data into 'reviews' table 
		$sql = "INSERT INTO reviews (author, reviewName, description, review, imageURL) VALUES (:author,:reviewName,:description,:review,:imageURL)";  
	
		//Prepare the query where data and variables match
		$stmt = $db->prepare($sql); 
		$stmt->bindParam(':author', $author, PDO::PARAM_STR);
		$stmt->bindParam(':reviewName', $reviewName, PDO::PARAM_STR); 
		$stmt->bindParam(':description', $description, PDO::PARAM_STR); 
		$stmt->bindParam(':review', $review, PDO::PARAM_STR); 
		$stmt->bindParam(':imageURL', $updateImageURL, PDO::PARAM_STR);
		$stmt->execute();
		
?>
	<!---Add review form !-->
	<form id="add" name="add" action ="addReview.php" method="post" enctype="multipart/form-data" onsubmit="return validateForm()">
		<label for="author">Author</label></br>
		<input type="text" name="author" value="<?php echo $_SESSION['username']; ?>" readonly></br></br>
		<label for="reviewName">Review name</label></br>
		<input type="text" name="reviewName" placeholder="Please add the review name..."/></br></br>
		<label for="description">Description</label></br>
		<textarea id="description" name="description" placeholder="Please add a description..." rows="3" cols="10"></textarea></br></br>
		<label for="review">Review</label></br>
		<textarea id="review" name="review" placeholder="Please add the review..." rows="5" cols="20"></textarea></br></br>
		<label for="file">Image:</label></br>
		<input type="file" name="image"></br></br>
		<input type="submit" name="submit" value="submit" onclick="textFunction()">
	</form>
	
<?php
//End the main function 				
echo endMain();

//Display the footer function
echo makeFooter();
?>

<script>
//form validation
function validateForm() {
    var x = document.forms["add"]["reviewName"].value;
    if (x == "") {
        alert("Review name must be filled out");
        return false;
    }
	    var x = document.forms["add"]["description"].value;
    if (x == "") {
        alert("Description must be filled out");
        return false;
    }
	var x = document.forms["add"]["image"].value; 
	if (x == ""){ 
	alert("Please select an image"); 
	return false; 
	}
}
</script>
<script>
function textFunction() {
  document.getElementById("description").maxLength = "100";
}
</script>
<script>
function textFunction() {
  document.getElementById("review").maxLength = "1000";
}
</script>