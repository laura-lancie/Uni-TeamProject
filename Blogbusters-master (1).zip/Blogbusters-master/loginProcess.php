<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Log In");

// If details are passed to the page, process the below
if (isset($_REQUEST['user']) && isset($_REQUEST['password'])) {

	// Start main page body
	echo startSmallMain();

		// Request items from log in form
		$user = $_REQUEST['user'];
		$password = $_REQUEST['password'];

		// If an @ symbol is used, process log in details as an email address
		if (strpos($user, '@') !== false) {
			$stmt = $db->query( "SELECT `userID`, `email`, `password`, `username`, `emailConfirm`, `suspensionEnd` FROM `users` WHERE `email` = '$user'");
		}
		
		// If an @ symbol is not used, process log in details as username
		else {
			$stmt = $db->query( "SELECT `userID`, `email`, `password`, `username`, `emailConfirm`, `suspensionEnd` FROM `users` WHERE `username` = '$user'");
		}

		// Process query
		$obj = $stmt->fetchObject();

		// If query has results, process them as below
		if($obj != null) {

			// If the provided password matches the password held on the database, check email confirmation status
			if (password_verify($password,$obj->password)){

				// If email has been confirmed, retrieve user suspension status
				if ($obj->emailConfirm == 1) {
				
					$today = date("Y-m-d");
					$suspensionEnd = date("Y-m-d",strtotime($obj->suspensionEnd));
					$displaySuspension = date("jS F Y",strtotime($obj->suspensionEnd));

					// If user is eligible to log in, finish the process and return to home page
					if ($today>=$suspensionEnd){
						$_SESSION['logged-in'] = true;
						$_SESSION['userID'] = $obj->userID;
						$_SESSION['email'] = $obj->email;
						$_SESSION['username'] = $obj->username;
						session_regenerate_id(true);
						header("location:index.php");
					}
					
					// If the user is not eligible to log in, return a message containing the suspension end date
					else {
						if ($suspensionEnd == "3000-01-01") {
								echo "<h1>Unable to Log In</h1>";
								echo "<p>Your account is currently suspended indefinitely</p>";
								echo "<p>Return to the <a href='index.php'>home page</a></p>";
						}
						else {	
								echo "<h1>Unable to Log In</h1>";
								echo "<p>Your account is currently suspended. The suspension will be lifted on ".$displaySuspension.".</p>";
								echo "<p>Return to the <a href='index.php'>home page</a></p>";
						}
					}
				}
				
				// If email has not been confirmed before log in
				else {
							echo "<h1>Unable to Log In</h1>";
							echo "<p>Please confirm your email address via the link provided</p>";
							echo "<p>If you have not recieved an email to your inbox, please check your spam folder</p>";
							echo "<p>Return to <a href='login.php'>log in</a></p>";
				}
			}
			
			// If the password details do not match, return a message to the user without displaying which element was incorrect
			else {
						echo "<h1>Unable to Log In</h1>";
						echo "<p>User credentials are incorrect. Return to <a href='login.php'>log in</a></p>";
			}
		}
		
		// If the log in details do not match, return a message to the user without displaying which element was incorrect
		else {
					echo "<h1>Unable to Log In</h1>";
					echo "<p>User credentials are incorrect. Return to <a href='login.php'>log in</a></p>";
		}
}

// If no details passed to page, display redirection message
else {
	// Start main page body
	echo startSmallMain();
				echo "<h1>Page Not Accessible</h1>";
				echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>