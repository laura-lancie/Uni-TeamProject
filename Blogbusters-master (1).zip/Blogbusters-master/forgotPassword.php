<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Forgotten Password");

// Start main page body
echo startSmallMain();
?>
		<!-- Display log in form !-->
		<h1 style="text-align: center;">Forgotten Password</h1>
		<p>Please enter the email address associated with your account. We will send you a link to reset your password</p>
		<form name="forgotPass" method="post" action="forgotProcess.php">
			<fieldset>
				<br />
				<label for="email">Email:</label><br />
				<input type="email" name="email" required><br /><br />
				<div style="width: 90%;">
				<input type="submit" name="submit" value="Submit" style="float: right;">
				</div>
				<br /><br />
			</fieldset>
		</form>
		<p style="text-align:center;">Return to <a href="login.php">log in</a></p>
<?php
// End main body
echo endMain();

// Display footer
echo makeFooter();
?>