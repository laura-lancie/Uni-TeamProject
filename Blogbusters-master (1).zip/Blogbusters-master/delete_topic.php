<?php
// Include header, menu and other functions, plus config
require_once( "functions.php" );
require_once( "config.php" );

// Set session path
$studentID = getStudentID();
ini_set( "session.save_path", "/home/" . $studentID . "/sessionData" );

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader( "Blogbusters | Delete Topic");


if ( isset( $_GET[ 'id' ] ) ) {
	$id = intval( $_GET[ 'id' ] );
	if ( isset( $_SESSION[ 'username' ] ) ) {
		$dn1 = mysql_fetch_array( mysql_query( 'select count(t.id) as nb1, t.title, t.parent, c.name from topics as t, categories as c where t.id="' . $id . '" and t.id2=1 and c.id=t.parent group by t.id' ) );
		if ( $dn1[ 'nb1' ] > 0 ) {
			if ( getAccessLevel($_SESSION[ 'username' ]) == "Administrator" ) {
				?>

					<div class="content">
						<?php
						$nb_new_pm = mysql_fetch_array( mysql_query( 'select count(*) as nb_new_pm from pm where ((user1="' . $_SESSION[ 'userID' ] . '" and user1read="no") or (user2="' . $_SESSION[ 'userID' ] . '" and user2read="no")) and id2="1"' ) );
						$nb_new_pm = $nb_new_pm[ 'nb_new_pm' ];
						?>
						<div class="box">
							<div class="box_left">
								<a href="discussIndex.php">Forum Home</a> &gt;
								<a href="list_topics.php?parent=<?php echo $dn1['parent']; ?>">
									<?php echo htmlentities($dn1['name'], ENT_QUOTES, 'UTF-8'); ?>
								</a> &gt;
								<a href="read_topic.php?id=<?php echo $id; ?>">
									<?php echo htmlentities($dn1['title'], ENT_QUOTES, 'UTF-8'); ?>
								</a> &gt; Delete the topic
							</div>
							<div class="box_right">
								<a href="list_pm.php">Your messages(<?php echo $nb_new_pm; ?>)</a> -
								<a href="profile.php">
									<?php echo htmlentities($_SESSION['username'], ENT_QUOTES, 'UTF-8'); ?>
								</a>
							</div>
							<div class="clean"></div>
						</div>
						<?php
						//deletes topic and then sends confimation message
						if ( isset( $_POST[ 'confirm' ] ) ) {
							if ( mysql_query( 'delete from topics where id="' . $id . '"' ) ) {
								?>		
						<div class="message">The topic has successfully been deleted.<br/>
							<a href="list_topics.php?parent=<?php echo $dn1['parent']; ?>">Go to "<?php echo htmlentities($dn1['name'], ENT_QUOTES, 'UTF-8'); ?>"</a>
						</div>
						<?php
						//displays error messsage and sends confirmation of deletion with user option yes/no
						} else {
							echo 'An error occured while deleting the topic.';
						}
						} else {
							?>
						<form action="delete_topic.php?id=<?php echo $id; ?>" method="post">
							Are you sure you want to delete this topic?
							<input type="hidden" name="confirm" value="true"/>
							<input type="submit" value="Yes"/> <input type="button" value="No" onclick="javascript:history.go(-1);"/>
						</form>
						<?php
						}
						?>
					</div>
				</html>
				<?php
				//Admin rights
			} else {
				echo '<h2>You don\'t have the right to delete this topic.</h2>';
			}
		} else {
			echo '<h2>The topic you want to delete doesn\'t exist.</h2>';
		}
	} else {
		echo '<h2>You must be logged as an administrator to access this page: <a href="login.php">Login</a> - <a href="register.php">Sign Up</a></h2>';
	}
} else {
	echo '<h2>The ID of the topic you want to delete is not defined.</h2>';
}
?>