<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Include PHPMailer functionality
use PHPMailer\PHPMailer\PHPMailer;

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Register");

// If details have been passed from previous page, process the below
if (isset($_REQUEST['username'])) {

	// Request data from registration form
	$firstName = $_REQUEST['firstName'];
	$surname = $_REQUEST['surname'];
	$email = $_REQUEST['email'];
	$username = $_REQUEST['username'];
	$password = $_REQUEST['password'];
	$passwordConfirm = $_REQUEST['passwordConfirm'];
	
	// Create join date
	$joinDate = date("Y-m-d");

	// Create password salt
	$options = ['cost'=>12,];

	// Return user to registration page if illegal character '@' is used in username
	if (strpos($username, '@') !== false) {
		// Start main page body
		echo startSmallMain();
					echo "<h1>Unable to Complete Registration</h1>";
					echo "<p>Username cannot contain &quot@&quot symbol. Return to <a href='register.php'>registration</a></p>";
	}
	
	else {
		// Return user to registration page if username already exists
		$stmt = $db->query( "SELECT `username` FROM `users` WHERE `username` = '$username'");
		$obj = $stmt->fetchObject();
		if (isset($obj->username)) {
			// Start main page body
			echo startSmallMain();
						echo "<h1>Unable to Complete Registration</h1>";
						echo "<p>Username is already in use. Return to <a href='register.php'>registration</a></p>";
			}
		
		else {
			// Return user to registration page if email already exists
			$stmt = $db->query( "SELECT `email` FROM `users` WHERE `email` = '$email'");
			$obj = $stmt->fetchObject();
			if (isset($obj->email)) {
				// Start main page body
				echo startSmallMain();
							echo "<h1>Unable to Complete Registration</h1>";
							echo "<p>Email is already in use. Return to <a href='register.php'>registration</a></p>";
			}
			
			// If password and password confirmation match, follow below processes
			else {
				if($password==$passwordConfirm){
				
					// Create encrypted password
					$passwordHash = password_hash($password,PASSWORD_DEFAULT,$options);
					
					// Set confirmation email
					$usernameHash = password_hash($username,PASSWORD_DEFAULT,$options); // Encrypted username
					include_once ("PHPMailer/PHPMailer.php");
					$mail = new PHPMailer();
					$mail->setFrom($studentEmail);
					$mail->addAddress($email, $username);
					$mail->Subject = "Blogbusters Email Verification";
					$mail->isHTML(true);
					$mail->Body = 	"<p>Hi, $username</p>
									<p>Thank you for registering with Blogbusters!</p>
									<p>Please click on the link below to verify your email and complete registration:</p>
									<p><a href='http://".$studentID.".newnumyspace.co.uk/".$directory."/emailConfirm.php?email=$email&username=$usernameHash'>Click here</a></p>";
					$mail->send();
				
					// Return a message to the user that the profile has been created and log in is pending email confirmation
					
					// Start main page body
					echo startSmallMain();
								echo "<h1>Registration Complete</h1>";
								echo "<p>You have created a profile with the following details:</p>";
								echo "<p><strong>Username:</strong> $username</p>";
								echo "<p><strong>Email:</strong> $email</p>";
								echo "<p>Confirm your registration via email to access our features!</p>";
								echo "<p>Please ensure to check your spam folder if the email is not in your inbox</p>";
				
					// Prepare SQL statement
					$sql = "INSERT INTO `users`(`firstName`, `surname`, `email`, `username`, `password`, `joinDate`) VALUES (:firstName, :surname, :email, :username, :password, :joinDate)";
				
					// Prepare values
					$stmt = $db->prepare($sql);
					$stmt->bindParam(':firstName', $firstName, PDO::PARAM_STR);
					$stmt->bindParam(':surname', $surname, PDO::PARAM_STR);
					$stmt->bindParam(':email', $email, PDO::PARAM_STR);
					$stmt->bindParam(':username', $username, PDO::PARAM_STR);
					$stmt->bindParam(':password', $passwordHash, PDO::PARAM_STR);
					$stmt->bindParam(':joinDate', $joinDate, PDO::PARAM_STR);

					// Execute statement
					$stmt->execute();
					
					// Prepare SQL statement
					$sqlDiscuss = "INSERT INTO `discussUsers`(`email`, `username`, `password`, `signup_date`) VALUES (:email, :username, :password, :joinDate)";
				
					// Prepare values
					$stmtDiscuss = $db->prepare($sqlDiscuss);
					$stmtDiscuss->bindParam(':email', $email, PDO::PARAM_STR);
					$stmtDiscuss->bindParam(':username', $username, PDO::PARAM_STR);
					$stmtDiscuss->bindParam(':password', $passwordHash, PDO::PARAM_STR);
					$stmtDiscuss->bindParam(':joinDate', $joinDate, PDO::PARAM_STR);

					// Execute statement
					$stmtDiscuss->execute();
				}
				
				// If provided passwords do not match, return a message to the user to return to the registration page
				else {
					echo startSmallMain();
								echo "<h1>Unable to Complete Registration</h1>";
								echo "<p>Provided passwords do not match. Return to <a href='register.php'>registration</a></p>";
				}
			}
		}
	}
}

// If no details have been passed, display redirection message
else {
	// Start main page body
	echo startSmallMain();
				echo "<h1>Page Not Accessible</h1>";
				echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>