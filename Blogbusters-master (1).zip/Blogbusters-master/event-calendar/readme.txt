This is downloaded from www.plus2net.com 
You can distribute this code with the link to www.plus2net.com 
Please don't  remove the link to www.plus2net.com 
This is for your learning only not for commercial use. 
The author is not responsible for any type of loss or problem or damage on using this script.
You can use it at your own risk.



Visit http://www.plus2net.com/jquery/event-calendar.php  for script updates and more details. 


Use the SQL_dump.txt file to create plus2net_event table  in your MySQL database
Open config.php file to enter your MySQL login details. 
Open display.php file to select date to see events. 
You can only select dates for which there event is there in our database table. 

Open add-event/add.php file to add or delete events. 

head.php file connects to jquery CDN.
You must have internet to get connected to google CDN , otherwise download the JQuery files and link them inside head.php




