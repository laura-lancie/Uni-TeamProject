<?php
// Include header, menu and other functions
require_once("functions.php");

// Set session path
$studentID = getStudentID();
ini_set("session.save_path", "/home/".$studentID."/sessionData");

// Start session
session_start();

// Connect to database
$db = getConnection();

// Display header and create page title
echo makeHeader("Blogbusters | Update");

// If details have been passed, process the below
if (isset($_POST["accessLevel"]) || isset($_POST["accessConfirm"]) || isset($_POST["suspend"]) || isset($_POST["suspendConfirm"]) || isset($_POST["delete"]) || isset($_POST["deleteConfirm"]) ) {

	// ACCESS LEVEL FUNCTIONALITY
	// Request username and new access level from admin page and create password verification
	if (isset($_POST["accessLevel"])) {
		echo startSmallMain();
					echo "<h1>Update Access</h1>";
					
					echo "<p>Enter your password to confirm the changes:</p>";
					echo "<form name='access' method='post' action=".$_SERVER['PHP_SELF'].">";
						echo "<fieldset>";
						
							echo "<input type='hidden' name='username' value=".$_REQUEST['username'].">";
							echo "<input type='hidden' name='setAccess' value=".$_REQUEST['setAccess'].">";
							
							echo "<label for='password'>Password:</label><br />";
							echo "<input type='password' name='password' required><br /><br />";
							echo "<label for='passwordConfirm'>Confirm Password:</label><br />";
							echo "<input type='password' name='passwordConfirm' required><br /><br />";
							echo "<div style='width: 90%;'>";
								echo "<input type='submit' name='accessConfirm' value='Update Access Level' style='float: right;'>";
							echo "</div>";
						echo "</fieldset>";
					echo "</form>";
					echo "<p style='text-align: center;'>Return to <a href='adminUsers.php'>user admin</a></p>";
	}

	// Request username and new access level from password verification
	if (isset($_POST["accessConfirm"])) {
		$username = $_REQUEST['username'];
		$updateAccess = $_REQUEST['setAccess'];
		
		$admin = $_SESSION['username'];
		
		$stmt = $db->query( "SELECT `password` FROM `users` WHERE `username` = '$admin'");
		$obj = $stmt->fetchObject();
		
		$password = $_REQUEST['password'];
		$passwordConfirm = $_REQUEST['passwordConfirm'];
		
		// Execute query if passwords are correct
		if (password_verify($password,$obj->password)&& $password == $passwordConfirm) {
			echo startSmallMain();
						echo "<h1>Access Updated</h1>";
						
						$sql = "UPDATE `users` SET `access`= :access WHERE `username` = '$username'";
						
						$stmt = $db->prepare($sql);
						$stmt->bindParam(':access', $updateAccess, PDO::PARAM_INT);
						
						$stmt->execute();
						
						$stmtAccess = $db->query( "SELECT `accessLevel` FROM `userAccess` WHERE `accessID` = '$updateAccess'");
						$objAccess = $stmtAccess->fetchObject();
						$newAccess = $objAccess->accessLevel;
						
						echo "<p>".$_REQUEST['username']." has been granted <strong>".$newAccess."</strong> level access</p>";
						echo "<p>Return to <a href='adminUsers.php'>user admin</a></p>";
		}
		// Return message if passwords incorrect
		else{
			echo startSmallMain();
						echo "<h1>Confirmation Failure</h1>";
						echo "<p>Provided passwords are incorrect. Return to <a href='adminUsers.php'>user admin</a></p>";
		}
	}

	// SUSPEND FUNCTIONALITY
	// Request username and suspension time from admin page and create password verification
	if (isset($_POST["suspend"])) {
		if ($_REQUEST['setSuspension']=="clear") {
			echo startSmallMain();
						echo "<h1>Clear Suspension</h1>";
						$today = date("Y-m-d");
						$suspension = date("Y-m-d",strtotime($today));
						$suspensionEnd = null;
		}
		else if ($_REQUEST['setSuspension']=="indefinite") {
			echo startSmallMain();
						echo "<h1>Suspend User</h1>";
							$suspension = date("Y-m-d",strtotime("3000-01-01"));
							$suspensionEnd = null;
		}
		else {
			echo startSmallMain();
						echo "<h1>Suspend User</h1>";
						$today = date("Y-m-d");
						$suspension = date("Y-m-d",strtotime($today. ' + '.$_REQUEST['setSuspension']));
						$suspensionEnd = date("jS F Y",strtotime($suspension));
		}
		
						echo "<p>Enter your password to confirm the changes:</p>";
						echo "<form name='suspend' method='post' action=".$_SERVER['PHP_SELF'].">";
							echo "<fieldset>";
							
								echo "<input type='hidden' name='username' value=".$_REQUEST['username'].">";
								echo "<input type='hidden' name='setSuspension' value=".$_REQUEST['setSuspension'].">";
								echo "<input type='hidden' name='suspension' value=".date("Y-m-d",strtotime($suspension)).">";
								echo "<input type='hidden' name='suspensionEnd' value='".$suspensionEnd."'>";
								
								echo "<label for='password'>Password:</label><br />";
								echo "<input type='password' name='password' required><br /><br />";
								echo "<label for='passwordConfirm'>Confirm Password:</label><br />";
								echo "<input type='password' name='passwordConfirm' required><br /><br />";
								echo "<div style='width: 90%;'>";
									if ($_REQUEST['setSuspension']=="clear") {
										echo "<input type='submit' name='suspendConfirm' value='Clear Suspension' style='float: right;'>";
									}
									else {
										echo "<input type='submit' name='suspendConfirm' value='Suspend User' style='float: right;'>";
									}
								echo "</div >";
							echo "</fieldset>";
						echo "</form>";
						echo "<p style='text-align: center;'>Return to <a href='adminUsers.php'>user admin</a></p>";
	}

	// Request username and suspension time from password verification
	if (isset($_POST["suspendConfirm"])) {
		$username = $_REQUEST['username'];
		$suspension = $_REQUEST['suspension'];
		$suspensionEnd = $_REQUEST['suspensionEnd'];
		
		$admin = $_SESSION['username'];
		
		$stmt = $db->query( "SELECT `password` FROM `users` WHERE `username` = '$admin'");
		$obj = $stmt->fetchObject();
		
		$password = $_REQUEST['password'];
		$passwordConfirm = $_REQUEST['passwordConfirm'];
		
		// Execute query if passwords are correct
		if (password_verify($password,$obj->password)&& $password == $passwordConfirm) {
			$sql = "UPDATE `users` SET `suspensionEnd`= :suspensionEnd WHERE `username` = '$username'";
			
			$stmt = $db->prepare($sql);
			$stmt->bindParam(':suspensionEnd', $suspension, PDO::PARAM_STR);
			
			$stmt->execute();
			
			if ($_REQUEST['setSuspension']=="clear") {
				echo startSmallMain();
							echo "<h1>Suspension Lifted</h1>";
							echo "<p>".$_REQUEST['username']." has had their suspension lifted</p>";
			}
			else if ($_REQUEST['setSuspension']=="indefinite") {
				echo startSmallMain();
							echo "<h1>User Suspended</h1>";
							echo "<p>".$_REQUEST['username']." has been suspended indefinitely</p>";
			}
			else {
				echo startSmallMain();
							echo "<h1>User Suspended</h1>";
							echo "<p>".$_REQUEST['username']." has been suspended until ".$suspensionEnd."</p>";
			}
							echo "<p style='text-align: center;'>Return to <a href='adminUsers.php'>user admin</a></p>";
		}
		// Return message if passwords incorrect
		else{
			echo startSmallMain();
						echo "<h1>Confirmation Failure</h1>";
						echo "<p>Provided passwords are incorrect. Return to <a href='adminUsers.php'>user admin</a></p>";
		}
	}

	// DELETE FUNCTIONALITY
	// Request username to be deleted and create password verification
	if (isset($_POST["delete"])) {
		echo startSmallMain();
					echo "<h1>Delete User</h1>";
				
					echo "<p>Enter your password to confirm the changes:</p>";
					echo "<form name='delete' method='post' action=".$_SERVER['PHP_SELF'].">";
						echo "<fieldset>";
						
							echo "<input type='hidden' name='username' value=".$_REQUEST['username'].">";
							
							echo "<label for='password'>Password:</label><br />";
							echo "<input type='password' name='password' required><br /><br />";
							echo "<label for='passwordConfirm'>Confirm Password:</label><br />";
							echo "<input type='password' name='passwordConfirm' required><br /><br />";
							echo "<div style='width: 90%;'>";
								echo "<input type='submit' name='deleteConfirm' value='Delete User' style='float: right;'>";
							echo "</div>";
						echo "</fieldset>";
					echo "</form>";
					echo "<p style='text-align: center;'>Return to <a href='adminUsers.php'>user admin</a></p>";
	}

	// Request username to be deleted from password verification
	if (isset($_POST["deleteConfirm"])) {
		$username = $_REQUEST['username'];
		
		$admin = $_SESSION['username'];
		
		$stmt = $db->query( "SELECT `password` FROM `users` WHERE `username` = '$admin'");
		$obj = $stmt->fetchObject();
		
		$password = $_REQUEST['password'];
		$passwordConfirm = $_REQUEST['passwordConfirm'];
		
		// Execute query if passwords are correct
		if (password_verify($password,$obj->password)&& $password == $passwordConfirm) {
			echo startSmallMain();
						echo "<h1>User Deleted</h1>";
				
						echo "<p>The profile for <strong>".$_REQUEST['username']."</strong> has been deleted</p>";
						echo "<p>Return to <a href='adminUsers.php'>user admin</a></p>";
			
			$sql = "DELETE FROM `users` WHERE `username` = '$username'";
			$stmt = $db->prepare($sql);
			$stmt->execute();
			
			$sqlDiscuss = "DELETE FROM `discussUsers` WHERE `username` = '$username'";
			$stmtDiscuss = $db->prepare($sqlDiscuss);
			$stmtDiscuss->execute();
		}
		// Return message if passwords incorrect
		else{
			echo startSmallMain();
						echo "<h1>Confirmation Failure</h1>";
						echo "<p>Provided passwords are incorrect. Return to <a href='adminUsers.php'>user admin</a></p>";
		}
	}
}
// If no details have been passed, display redirection message
else {
	// Start main page body
	echo startSmallMain();
				echo "<h1>Page Not Accessible</h1>";
				echo "You do not have permission to access this page. Please return to the <a href='index.php'>home page</a>.";
}

// End main body
echo endMain();

// Display footer
echo makeFooter();
?>